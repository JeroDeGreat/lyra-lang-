const vscode = require('vscode');
const path   = require('path');

function activate(context) {

    function getLyraPath() {
        const config = vscode.workspace.getConfiguration('lyra');
        const raw = config.get('executablePath', 'lyra');
        // Strip any surrounding quotes the user may have added
        return raw.replace(/^["']+|["']+$/g, '').trim();
    }

    // ── Run file ──────────────────────────────────────────────────
    const runCmd = vscode.commands.registerCommand('lyra.runFile', () => {
        const editor = vscode.window.activeTextEditor;
        if (!editor) {
            vscode.window.showErrorMessage('Lyra: No file open.');
            return;
        }
        if (!editor.document.fileName.endsWith('.lyr')) {
            vscode.window.showErrorMessage('Lyra: This only works on .lyr files.');
            return;
        }
        editor.document.save().then(() => {
            const lyraPath = getLyraPath();
            const filePath = editor.document.fileName;
            const terminal = vscode.window.createTerminal({
                name: `Lyra ▶ ${path.basename(filePath)}`,
                cwd:  path.dirname(filePath)
            });
            terminal.show(true);
            // & operator handles paths with spaces on Windows PowerShell
            terminal.sendText(`& "${lyraPath}" run "${filePath}"`);
        });
    });

    // ── Check syntax ──────────────────────────────────────────────
    const checkCmd = vscode.commands.registerCommand('lyra.checkFile', () => {
        const editor = vscode.window.activeTextEditor;
        if (!editor) return;
        const lyraPath = getLyraPath();
        const filePath = editor.document.fileName;
        const terminal = vscode.window.createTerminal({ name: 'Lyra Check' });
        terminal.show(true);
        terminal.sendText(`& "${lyraPath}" check "${filePath}"`);
    });

    // ── Hover docs ────────────────────────────────────────────────
    const hoverProvider = vscode.languages.registerHoverProvider('lyra', {
        provideHover(document, position) {
            const range = document.getWordRangeAtPosition(
                position, /[a-zA-Z][a-zA-Z0-9 _]*/
            );
            if (!range) return;
            const word = document.getText(range).toLowerCase().trim();
            const doc  = DOCS[word];
            if (doc) return new vscode.Hover(new vscode.MarkdownString(doc));
        }
    });

    // ── Completions ───────────────────────────────────────────────
    const completionProvider = vscode.languages.registerCompletionItemProvider(
        'lyra',
        {
            provideCompletionItems(document, position) {
                const items = [];
                for (const [label, snippet, detail] of COMPLETIONS) {
                    const item = new vscode.CompletionItem(label, vscode.CompletionItemKind.Keyword);
                    item.insertText = new vscode.SnippetString(snippet);
                    item.detail = detail;
                    items.push(item);
                }
                const linePrefix = document.lineAt(position).text
                    .substring(0, position.character);
                if (/\buse\s+$/i.test(linePrefix)) {
                    for (const mod of MODULES) {
                        const item = new vscode.CompletionItem(mod, vscode.CompletionItemKind.Module);
                        item.insertText = `${mod}.`;
                        item.detail = 'Lyra standard library module';
                        items.push(item);
                    }
                }
                return items;
            }
        },
        ' '
    );

    context.subscriptions.push(runCmd, checkCmd, hoverProvider, completionProvider);
}

function deactivate() {}

// ── Static data ───────────────────────────────────────────────────

const MODULES = [
    'math','files','web','time','random','os','json',
    'gui','data','ml','crypto','net','server','blockchain'
];

const COMPLETIONS = [
    ['let',         'let ${1:name} be ${2:value}.',                             'Declare a variable'],
    ['set',         'set ${1:name} to ${2:value}.',                             'Reassign a variable'],
    ['say',         'say "${1:Hello!}".',                                        'Print to output'],
    ['ask',         'ask "${1:What is your name?}" into ${2:name}.',            'Read user input'],
    ['if',          'if ${1:condition}.\n  ${2:say "yes".}\nend if.',           'If statement'],
    ['if else',     'if ${1:condition}.\n  ${2:say "yes".}\nelse.\n  ${3:say "no".}\nend if.', 'If else'],
    ['repeat',      'repeat ${1:5} times.\n  ${2:say "Hello!".}\nend repeat.', 'Repeat N times'],
    ['repeat from', 'repeat from ${1:1} to ${2:10}.\n  say the current count.\nend repeat.', 'Repeat range'],
    ['while',       'while ${1:condition}.\n  ${2:say "loop.".}\nend while.',   'While loop'],
    ['for each',    'for each ${1:item} in ${2:items}.\n  say ${1:item}.\nend for.', 'For each loop'],
    ['define',      'define ${1:myFunction} taking ${2:argument}.\n  ${3:return argument.}\nend define.', 'Define function'],
    ['define no args', 'define ${1:myFunction}.\n  ${2:say "Hello.".}\nend define.', 'Function no args'],
    ['return',      'return ${1:value}.',                                        'Return value'],
    ['try',         'try.\n  ${1:say "Trying.".}\ncatch error.\n  say "Error: {error}".\nend try.', 'Try catch'],
    ['raise',       'raise error "${1:Something went wrong.}".',                'Raise error'],
    ['use',         'use ${1|math,files,web,time,random,os,json,gui,data,ml,crypto,net,server,blockchain|}.',  'Import module'],
    ['note',        'note ${1:comment}',                                         'Comment'],
    ['let list',    'let ${1:items} be a list of ${2:"one"}, ${3:"two"}.',      'Create list'],
    ['let map',     'let ${1:data} be a map with ${2:"key"} as ${3:"value"}.',  'Create map'],
    ['add to',      'add ${1:value} to ${2:variable}.',                         'Add to variable or list'],
    ['subtract',    'subtract ${1:value} from ${2:variable}.',                  'Subtract'],
    ['multiply',    'multiply ${1:variable} by ${2:value}.',                    'Multiply'],
    ['divide',      'divide ${1:variable} by ${2:value}.',                      'Divide'],
    ['remove',      'remove ${1:value} from ${2:list}.',                        'Remove from list'],
    ['write file',  'write ${1:content} to file "${2:output.txt}".',            'Write file'],
    ['read file',   'let ${1:content} be the content of file "${2:input.txt}".', 'Read file'],
    ['define class',
`define class \${1:MyClass}.
  it has \${2:name}.

  define create taking \${2:name}.
    set its \${2:name} to \${2:name}.
  end define.

  define describe.
    say "{its \${2:name}}".
  end define.
end class.`,                                                                     'Define class'],
    ['connect db',  'connect to database "${1:app.db}" as ${2:db}.',            'Connect SQLite'],
    ['sql execute', 'execute "${1:SQL}" on ${2:db}.',                           'Execute SQL'],
    ['sql query',   'let ${1:rows} be query ${2:db} with "${3:SELECT * FROM t}".', 'Query SQL'],
    ['http get',    'let ${1:response} be get "${2:https://api.example.com}".',  'HTTP GET'],
    ['parse json',  'let ${1:data} be parse ${2:response} as json.',            'Parse JSON'],
    ['open window', 'use gui.\nset theme to "dark".\nopen a window titled "${1:My App}" with width ${2:800}, height ${3:600}.', 'Open GUI window'],
    ['create label','create a label named ${1:myLabel} saying "${2:Hello!}".',  'Create label'],
    ['create button','create a button named ${1:myBtn} saying "${2:Click Me}" that calls ${3:onClick}.', 'Create button'],
    ['create input','create a text input named ${1:myInput} with placeholder "${2:Type here}".', 'Create text input'],
    ['create chart','create a ${1|bar,line,pie|} chart named ${2:myChart} titled "${3:Title}".', 'Create chart'],
    ['show window', 'show window.',                                              'Show the window'],
];

const DOCS = {
    'let':     '**`let`** — Declare a variable.\n\n```\nlet name be "Alice".\n```',
    'set':     '**`set`** — Change a variable.\n\n```\nset age to 26.\n```',
    'say':     '**`say`** — Print to output.\n\n```\nsay "Hello, {name}!".\n```',
    'ask':     '**`ask`** — Read user input.\n\n```\nask "Your name?" into name.\n```',
    'if':      '**`if`** — Conditional.\n\n```\nif age is at least 18.\n  say "Adult.".\nend if.\n```',
    'repeat':  '**`repeat`** — Loop.\n\n```\nrepeat 5 times.\n  say "Hi!".\nend repeat.\n```',
    'while':   '**`while`** — Loop while true.',
    'define':  '**`define`** — Create a function.\n\n```\ndefine greet taking name.\n  say "Hi, {name}!".\nend define.\n```',
    'return':  '**`return`** — Return a value.',
    'use':     '**`use`** — Import a module.\n\n`use math.` `use files.` `use gui.` `use data.` `use ml.`',
    'try':     '**`try`** — Handle errors.',
    'raise':   '**`raise`** — Throw an error.',
    'stop':    '**`stop`** — Break out of a loop.',
    'skip':    '**`skip`** — Skip to next iteration.',
    'note':    '**`note`** — A comment (ignored by Lyra).',
    'plus':    '**`plus`** — Addition: `a plus b`',
    'minus':   '**`minus`** — Subtraction: `a minus b`',
    'times':   '**`times`** — Multiplication: `a times b`',
    'and':     '**`and`** — Logical AND',
    'or':      '**`or`** — Logical OR',
    'not':     '**`not`** — Logical NOT',
    'yes':     '**`yes`** — Boolean true',
    'no':      '**`no`** — Boolean false',
    'nothing': '**`nothing`** — Null / empty value',
    'gui':     '**gui module** — Modern dark-mode GUI apps with charts, tables, and widgets.',
    'data':    '**data module** — CSV, statistics, filtering, sorting, normalization.',
    'ml':      '**ml module** — Machine learning: Naive Bayes, k-NN, linear regression, k-Means.',
    'crypto':  '**crypto module** — Hashing, tokens, password tools, encryption.',
    'net':     '**net module** — DNS, port scanning, TCP, URL tools.',
    'server':  '**server module** — Build HTTP servers in Lyra.',
    'blockchain': '**blockchain module** — Build and validate blockchains.',
};

module.exports = { activate, deactivate };
