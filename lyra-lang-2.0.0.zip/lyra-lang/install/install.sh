#!/usr/bin/env bash
# ============================================================================
#  Quill Language Installer — Linux & macOS
#  Installs Quill, adds it to PATH, and registers .ql file type
# ============================================================================

set -e

QUILL_VERSION="1.0.0"
INSTALL_DIR="$HOME/.quill"
BIN_DIR="$INSTALL_DIR/bin"
ICON_URL="https://quill-lang.org/assets/quill-icon.png"

GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BOLD='\033[1m'
RESET='\033[0m'

# ── Banner ────────────────────────────────────────────────────────────────────
echo ""
echo -e "${BLUE}${BOLD}"
echo "  ___  _  _  _  _     _   "
echo " / _ \| || || || |   | |  "
echo "| | | | || || || |   | |  "
echo "| |_| | \\  // || |___| |___"
echo " \__\_\\/\/\/ |_____|_____|"
echo ""
echo -e "${RESET}${BOLD}  Quill v${QUILL_VERSION} — Write code the way you think.${RESET}"
echo ""
echo -e "  Installing to: ${YELLOW}${INSTALL_DIR}${RESET}"
echo ""

# ── Check Python ──────────────────────────────────────────────────────────────
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}❌ Python 3 is required but not found.${RESET}"
    echo "   Please install Python 3.10+ from https://python.org"
    exit 1
fi

PYTHON_VERSION=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
echo -e "  ${GREEN}✓${RESET} Python $PYTHON_VERSION found"

# ── Detect OS ────────────────────────────────────────────────────────────────
OS="$(uname -s)"
case "$OS" in
    Linux*)  PLATFORM="linux";;
    Darwin*) PLATFORM="macos";;
    *)       PLATFORM="unknown";;
esac
echo -e "  ${GREEN}✓${RESET} Platform: $PLATFORM"

# ── Create install directory ──────────────────────────────────────────────────
echo ""
echo -e "  ${BLUE}→${RESET} Creating install directory..."
mkdir -p "$INSTALL_DIR"
mkdir -p "$BIN_DIR"
mkdir -p "$INSTALL_DIR/lib"
mkdir -p "$INSTALL_DIR/examples"
mkdir -p "$INSTALL_DIR/share/icons"

# ── Copy Quill runtime ────────────────────────────────────────────────────────
echo -e "  ${BLUE}→${RESET} Installing Quill runtime..."

# Detect source directory (the folder this script is in, or CWD)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SOURCE_DIR="$SCRIPT_DIR"

if [ -d "$SOURCE_DIR/quill" ]; then
    cp -r "$SOURCE_DIR/quill" "$INSTALL_DIR/"
    echo -e "  ${GREEN}✓${RESET} Runtime installed"
else
    echo -e "${RED}❌ Quill source not found at $SOURCE_DIR/quill${RESET}"
    echo "   Make sure you're running this script from the quill-lang directory."
    exit 1
fi

# Copy examples
if [ -d "$SOURCE_DIR/examples" ]; then
    cp -r "$SOURCE_DIR/examples" "$INSTALL_DIR/"
fi

# Copy icon
if [ -f "$SOURCE_DIR/install/quill-icon.png" ]; then
    cp "$SOURCE_DIR/install/quill-icon.png" "$INSTALL_DIR/share/icons/"
fi

# ── Create the `quill` launcher script ───────────────────────────────────────
echo -e "  ${BLUE}→${RESET} Creating launcher..."

cat > "$BIN_DIR/quill" << EOF
#!/usr/bin/env bash
# Quill launcher
export QUILL_HOME="$INSTALL_DIR"
export PYTHONPATH="$INSTALL_DIR:\$PYTHONPATH"
exec python3 -m quill "\$@"
EOF

chmod +x "$BIN_DIR/quill"
echo -e "  ${GREEN}✓${RESET} Launcher created at $BIN_DIR/quill"

# ── Install Python dependencies ───────────────────────────────────────────────
echo -e "  ${BLUE}→${RESET} Checking Python dependencies..."
python3 -c "import tkinter" 2>/dev/null && echo -e "  ${GREEN}✓${RESET} tkinter available" || \
    echo -e "  ${YELLOW}⚠${RESET}  tkinter not found — GUI features may not work."

# ── Add to PATH ───────────────────────────────────────────────────────────────
echo ""
echo -e "  ${BLUE}→${RESET} Adding Quill to PATH..."

PATH_LINE="export PATH=\"\$PATH:$BIN_DIR\""

add_to_file() {
    local FILE="$1"
    if [ -f "$FILE" ]; then
        if ! grep -q "$BIN_DIR" "$FILE" 2>/dev/null; then
            echo "" >> "$FILE"
            echo "# Quill Language" >> "$FILE"
            echo "$PATH_LINE" >> "$FILE"
            echo -e "  ${GREEN}✓${RESET} Added to $FILE"
        else
            echo -e "  ${YELLOW}↳${RESET} Already in $FILE (skipped)"
        fi
    fi
}

add_to_file "$HOME/.bashrc"
add_to_file "$HOME/.bash_profile"
add_to_file "$HOME/.zshrc"
add_to_file "$HOME/.profile"

# ── Register .ql file type ────────────────────────────────────────────────────
echo ""
echo -e "  ${BLUE}→${RESET} Registering .ql file type..."

if [ "$PLATFORM" = "linux" ]; then

    # ── xdg-mime registration (Linux desktop) ────────────────────────────────
    MIME_DIR="$HOME/.local/share/mime/packages"
    APPS_DIR="$HOME/.local/share/applications"
    ICONS_DIR="$HOME/.local/share/icons/hicolor/128x128/mimetypes"

    mkdir -p "$MIME_DIR" "$APPS_DIR" "$ICONS_DIR"

    # MIME type XML
    cat > "$MIME_DIR/quill.xml" << 'MIMEEOF'
<?xml version="1.0" encoding="UTF-8"?>
<mime-info xmlns="http://www.freedesktop.org/standards/shared-mime-info">
  <mime-type type="text/x-quill">
    <comment>Quill Source File</comment>
    <glob pattern="*.ql"/>
    <icon name="text-x-quill"/>
    <magic priority="50">
      <match type="string" offset="0" value="note "/>
      <match type="string" offset="0" value="let "/>
      <match type="string" offset="0" value="say "/>
      <match type="string" offset="0" value="define "/>
    </magic>
  </mime-type>
</mime-info>
MIMEEOF

    # Desktop entry
    cat > "$APPS_DIR/quill.desktop" << EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=Quill
GenericName=Quill Language
Comment=Run Quill (.ql) programs
Exec=$BIN_DIR/quill run %f
Icon=$INSTALL_DIR/share/icons/quill-icon.png
Terminal=true
Categories=Development;IDE;TextEditor;
MimeType=text/x-quill;
Keywords=quill;programming;ql;
StartupNotify=true
EOF

    # Icon for MIME type
    if [ -f "$INSTALL_DIR/share/icons/quill-icon.png" ]; then
        cp "$INSTALL_DIR/share/icons/quill-icon.png" "$ICONS_DIR/text-x-quill.png"
    fi

    # Update MIME database
    if command -v update-mime-database &>/dev/null; then
        update-mime-database "$HOME/.local/share/mime" 2>/dev/null && \
            echo -e "  ${GREEN}✓${RESET} MIME database updated"
    fi

    # Update desktop database
    if command -v update-desktop-database &>/dev/null; then
        update-desktop-database "$APPS_DIR" 2>/dev/null && \
            echo -e "  ${GREEN}✓${RESET} Desktop database updated"
    fi

    # Update icon cache
    if command -v gtk-update-icon-cache &>/dev/null; then
        gtk-update-icon-cache "$HOME/.local/share/icons/hicolor" 2>/dev/null || true
    fi

    echo -e "  ${GREEN}✓${RESET} .ql files registered as 'Quill Source File' on Linux"

elif [ "$PLATFORM" = "macos" ]; then

    # ── macOS UTI registration via Info.plist ─────────────────────────────────
    PLIST_DIR="$INSTALL_DIR/quill-filetype.app/Contents"
    mkdir -p "$PLIST_DIR"

    cat > "$PLIST_DIR/Info.plist" << 'PLISTEOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleIdentifier</key>
  <string>org.quill-lang.quill</string>
  <key>CFBundleName</key>
  <string>Quill</string>
  <key>CFBundleVersion</key>
  <string>1.0.0</string>
  <key>UTExportedTypeDeclarations</key>
  <array>
    <dict>
      <key>UTTypeIdentifier</key>
      <string>org.quill-lang.source</string>
      <key>UTTypeDescription</key>
      <string>Quill Source File</string>
      <key>UTTypeConformsTo</key>
      <array>
        <string>public.source-code</string>
        <string>public.plain-text</string>
      </array>
      <key>UTTypeTagSpecification</key>
      <dict>
        <key>public.filename-extension</key>
        <array>
          <string>ql</string>
        </array>
        <key>public.mime-type</key>
        <string>text/x-quill</string>
      </dict>
    </dict>
  </array>
  <key>CFBundleDocumentTypes</key>
  <array>
    <dict>
      <key>CFBundleTypeName</key>
      <string>Quill Source File</string>
      <key>CFBundleTypeExtensions</key>
      <array>
        <string>ql</string>
      </array>
      <key>CFBundleTypeMIMETypes</key>
      <array>
        <string>text/x-quill</string>
      </array>
      <key>LSItemContentTypes</key>
      <array>
        <string>org.quill-lang.source</string>
      </array>
      <key>CFBundleTypeRole</key>
      <string>Editor</string>
    </dict>
  </array>
</dict>
</plist>
PLISTEOF

    # Register with Launch Services
    if command -v /System/Library/Frameworks/CoreServices.framework/Versions/A/Frameworks/LaunchServices.framework/Versions/A/Support/lsregister &>/dev/null; then
        /System/Library/Frameworks/CoreServices.framework/Versions/A/Frameworks/LaunchServices.framework/Versions/A/Support/lsregister \
            -f "$INSTALL_DIR/quill-filetype.app" 2>/dev/null || true
    fi

    echo -e "  ${GREEN}✓${RESET} .ql files registered as 'Quill Source File' on macOS"

    # Homebrew shell completions
    if command -v brew &>/dev/null; then
        COMPLETION_DIR="$(brew --prefix)/share/bash-completion/completions"
        mkdir -p "$COMPLETION_DIR"
        echo "complete -W 'run check new build repl version help' quill" > "$COMPLETION_DIR/quill"
    fi
fi

# ── Shell completion ──────────────────────────────────────────────────────────
BASH_COMPLETION_DIR="$HOME/.local/share/bash-completion/completions"
mkdir -p "$BASH_COMPLETION_DIR"
cat > "$BASH_COMPLETION_DIR/quill" << 'COMP'
_quill_completion() {
    local cur prev
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"
    if [ $COMP_CWORD -eq 1 ]; then
        COMPREPLY=($(compgen -W "run check new build repl version help" -- "$cur"))
    elif [ "$prev" = "run" ] || [ "$prev" = "check" ] || [ "$prev" = "build" ]; then
        COMPREPLY=($(compgen -f -X "!*.ql" -- "$cur"))
    fi
}
complete -F _quill_completion quill
COMP

# ZSH completion
if [ -d "$HOME/.oh-my-zsh" ] || command -v zsh &>/dev/null; then
    ZSH_FPATH="$HOME/.zsh/completions"
    mkdir -p "$ZSH_FPATH"
    cat > "$ZSH_FPATH/_quill" << 'ZCOMP'
#compdef quill
_quill() {
    local -a subcommands
    subcommands=('run:Run a Quill file' 'check:Check syntax' 'new:Create project' 'build:Build executable' 'repl:Launch REPL' 'version:Show version' 'help:Show help')
    _describe 'quill commands' subcommands
    case $words[2] in
        run|check|build)
            _files -g '*.ql'
            ;;
    esac
}
_quill
ZCOMP
fi

# ── Verify installation ───────────────────────────────────────────────────────
echo ""
echo -e "  ${BLUE}→${RESET} Verifying installation..."
export PATH="$PATH:$BIN_DIR"

if "$BIN_DIR/quill" version &>/dev/null; then
    echo -e "  ${GREEN}✓${RESET} Quill installed successfully!"
else
    echo -e "  ${YELLOW}⚠${RESET}  Could not verify — check PATH after reloading shell"
fi

# ── Done ──────────────────────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}${BOLD}  ✅ Quill v${QUILL_VERSION} installed!${RESET}"
echo ""
echo "  ╔═══════════════════════════════════════════════════╗"
echo "  ║  Getting started:                                 ║"
echo "  ║                                                   ║"
echo "  ║    Restart your terminal, then:                   ║"
echo "  ║                                                   ║"
echo "  ║    quill repl            # Interactive REPL       ║"
echo "  ║    quill new myproject   # New project            ║"
echo "  ║    quill run hello.ql    # Run a file             ║"
echo "  ║    quill help            # All commands           ║"
echo "  ║                                                   ║"
echo "  ║  VS Code extension: search 'Quill Language'       ║"
echo "  ║  Docs: https://quill-lang.org/docs                ║"
echo "  ╚═══════════════════════════════════════════════════╝"
echo ""
echo -e "  ${YELLOW}Restart your terminal to activate the 'quill' command.${RESET}"
echo ""
