from setuptools import setup, find_packages

setup(
    name='lyra-lang',
    version='2.0.0',
    description='Lyra — Write code the way you think.',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    author='Jero W. Grabo',
    url='https://lyra-lang.org',
    packages=find_packages(),
    python_requires='>=3.10',
    entry_points={
        'console_scripts': [
            'lyra=lyra.__main__:main',
        ],
    },
)
