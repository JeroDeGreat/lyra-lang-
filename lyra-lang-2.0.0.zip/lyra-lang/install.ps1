# Lyra Language 2.0 Installer for Windows
# Run with: powershell -ExecutionPolicy Bypass -File ".\install.ps1"

$LyraVersion = "2.0.0"
$InstallDir  = Join-Path $env:APPDATA "Lyra"
$BinDir      = Join-Path $InstallDir "bin"
$ScriptDir   = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host ""
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "  Lyra $LyraVersion  - Write code the way you think." -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host ""

# Find Python
Write-Host "  -> Checking for Python 3.10 or newer..." -ForegroundColor Blue
$Python = $null
foreach ($cmd in @("python3", "python")) {
    try {
        $v = & $cmd -c "import sys; v=sys.version_info; print(v[0],v[1])" 2>$null
        if ($v) {
            $parts = $v.Trim() -split ' '
            if ([int]$parts[0] -ge 3 -and [int]$parts[1] -ge 10) {
                $Python = $cmd
                Write-Host "  OK Found Python $($parts[0]).$($parts[1])" -ForegroundColor Green
                break
            }
        }
    } catch {}
}
if (-not $Python) {
    Write-Host "  ERROR: Python 3.10+ required. Install from python.org" -ForegroundColor Red
    exit 1
}

# Directories
Write-Host "  -> Creating install directory..." -ForegroundColor Blue
New-Item -ItemType Directory -Force -Path $BinDir | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $InstallDir "lib") | Out-Null
Write-Host "  OK Directory ready" -ForegroundColor Green

# Copy interpreter
Write-Host "  -> Copying Lyra interpreter..." -ForegroundColor Blue
$LyraSrc = Join-Path $ScriptDir "lyra"
$LyraDst = Join-Path $InstallDir "lib\lyra"
if (Test-Path $LyraSrc) {
    if (Test-Path $LyraDst) { Remove-Item -Recurse -Force $LyraDst }
    Copy-Item -Recurse $LyraSrc $LyraDst
    Write-Host "  OK Interpreter installed" -ForegroundColor Green
} else {
    Write-Host "  ERROR: Cannot find lyra source at $LyraSrc" -ForegroundColor Red
    exit 1
}

# CustomTkinter
Write-Host "  -> Installing CustomTkinter (modern UI)..." -ForegroundColor Blue
try {
    & $Python -m pip install --quiet customtkinter 2>$null
    Write-Host "  OK CustomTkinter installed (beautiful modern UI)" -ForegroundColor Green
} catch {
    Write-Host "  WARN CustomTkinter not installed - GUI will use standard tkinter" -ForegroundColor Yellow
}

# Launcher
Write-Host "  -> Creating lyra.bat launcher..." -ForegroundColor Blue
$LibDir = Join-Path $InstallDir "lib"
$BatchLines = "@echo off", "set PYTHONPATH=$LibDir;%PYTHONPATH%", "$Python -m lyra %*"
$BatchPath = Join-Path $BinDir "lyra.bat"
$BatchLines | Set-Content -Path $BatchPath -Encoding ASCII
Write-Host "  OK Launcher created: $BatchPath" -ForegroundColor Green

# Copy vsix if present
$VsixSrc = Join-Path $ScriptDir "lyra-lang.vsix"
if (Test-Path $VsixSrc) {
    Copy-Item $VsixSrc (Join-Path $InstallDir "lyra-lang.vsix")
}

# File type registration
Write-Host "  -> Registering .lyr file type..." -ForegroundColor Blue
try {
    New-Item -Path "HKCU:\Software\Classes\.lyr" -Force | Out-Null
    Set-ItemProperty -Path "HKCU:\Software\Classes\.lyr" -Name "(Default)" -Value "LyraSourceFile"
    Set-ItemProperty -Path "HKCU:\Software\Classes\.lyr" -Name "Content Type" -Value "text/x-lyra"
    New-Item -Path "HKCU:\Software\Classes\LyraSourceFile" -Force | Out-Null
    Set-ItemProperty -Path "HKCU:\Software\Classes\LyraSourceFile" -Name "(Default)" -Value "Lyra Source File"
    New-Item -Path "HKCU:\Software\Classes\LyraSourceFile\shell\open\command" -Force | Out-Null
    Set-ItemProperty -Path "HKCU:\Software\Classes\LyraSourceFile\shell\open\command" -Name "(Default)" -Value "`"$BinDir\lyra.bat`" run `"%1`""
    Write-Host "  OK .lyr file type registered" -ForegroundColor Green
} catch {
    Write-Host "  WARN File type registration skipped" -ForegroundColor Yellow
}

# PATH
Write-Host "  -> Adding Lyra to your PATH..." -ForegroundColor Blue
$CurrentPath = [Environment]::GetEnvironmentVariable("Path", "User")
if ($CurrentPath -notlike "*$BinDir*") {
    [Environment]::SetEnvironmentVariable("Path", "$BinDir;$CurrentPath", "User")
    $env:Path = "$BinDir;$env:Path"
    Write-Host "  OK Added $BinDir to PATH" -ForegroundColor Green
} else {
    Write-Host "  OK Already in PATH" -ForegroundColor Green
}

# VS Code extension
if (Get-Command code -ErrorAction SilentlyContinue) {
    $VsixInst = Join-Path $InstallDir "lyra-lang.vsix"
    if (Test-Path $VsixInst) {
        try {
            & code --install-extension $VsixInst --force 2>$null
            Write-Host "  OK VS Code extension installed" -ForegroundColor Green
        } catch {}
    }
}

# Verify
Write-Host "  -> Verifying..." -ForegroundColor Blue
try {
    $env:PYTHONPATH = "$LibDir;$env:PYTHONPATH"
    $ver = & "$BinDir\lyra.bat" version 2>$null
    Write-Host "  OK $ver" -ForegroundColor Green
} catch {
    Write-Host "  WARN Open a new terminal before using lyra" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "  Lyra 2.0 is ready!" -ForegroundColor Green
Write-Host ""
Write-Host "  Open a NEW PowerShell window, then try:" -ForegroundColor White
Write-Host "    lyra version" -ForegroundColor Cyan
Write-Host "    lyra run examples\hello_world.lyr" -ForegroundColor Cyan
Write-Host "    lyra run examples\v2\dashboard.lyr" -ForegroundColor Cyan
Write-Host "    lyra run examples\games\quill_quest\quill_quest.lyr" -ForegroundColor Cyan
Write-Host ""
