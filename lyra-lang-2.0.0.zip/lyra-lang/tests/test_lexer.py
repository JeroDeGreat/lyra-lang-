"""Tests for the Quill lexer."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from lyra.lexer import tokenize, KEYWORD, IDENTIFIER, STRING, NUMBER, DECIMAL, COMMA, PERIOD, EOF

def tok_types(source):
    return [(t.type, t.value) for t in tokenize(source) if t.type != 'INDENT' and t.type != 'DEDENT']

def test_hello_world():
    tokens = tok_types('say "Hello, World!".')
    assert (KEYWORD, 'say') in tokens
    assert (STRING, 'Hello, World!') in tokens
    assert (PERIOD, '.') in tokens

def test_number_literal():
    tokens = tok_types('let x be 42.')
    assert (NUMBER, '42') in tokens

def test_decimal_literal():
    tokens = tok_types('let pi be 3.14.')
    assert (DECIMAL, '3.14') in tokens

def test_compound_keyword_is_greater_than():
    tokens = tok_types('if age is greater than 18.')
    values = [v for _, v in tokens]
    assert 'is greater than' in values

def test_compound_keyword_end_if():
    tokens = tok_types('end if.')
    values = [v for _, v in tokens]
    assert 'end if' in values

def test_boolean_yes_no():
    tokens = tok_types('let active be yes.')
    values = [v for _, v in tokens]
    assert 'yes' in values

def test_string_with_comma():
    tokens = tok_types('say "Hello, World!".')
    strings = [v for t, v in tokens if t == STRING]
    assert 'Hello, World!' in strings

def test_case_insensitive():
    t1 = [(t, v.lower()) for t, v in tok_types('LET x BE 5.')]
    t2 = [(t, v.lower()) for t, v in tok_types('let x be 5.')]
    assert t1 == t2

if __name__ == '__main__':
    test_hello_world()
    test_number_literal()
    test_decimal_literal()
    test_compound_keyword_is_greater_than()
    test_compound_keyword_end_if()
    test_boolean_yes_no()
    test_string_with_comma()
    test_case_insensitive()
    print("All lexer tests passed!")
