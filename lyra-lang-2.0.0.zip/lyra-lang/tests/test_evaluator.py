"""Tests for the Quill evaluator."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from lyra.evaluator import run

def test_arithmetic():
    # We test by checking stdout using capsys-style redirect
    import io, contextlib
    out = io.StringIO()
    with contextlib.redirect_stdout(out):
        run('let x be 2 plus 3.\nsay x.')
    assert '5' in out.getvalue()

def test_string_interpolation():
    import io, contextlib
    out = io.StringIO()
    with contextlib.redirect_stdout(out):
        run('let name be "World".\nsay "Hello, {name}!".')
    assert 'Hello, World!' in out.getvalue()

def test_if_true():
    import io, contextlib
    out = io.StringIO()
    with contextlib.redirect_stdout(out):
        run('let x be 10.\nif x is greater than 5.\n  say "big".\nend if.')
    assert 'big' in out.getvalue()

def test_if_false():
    import io, contextlib
    out = io.StringIO()
    with contextlib.redirect_stdout(out):
        run('let x be 3.\nif x is greater than 5.\n  say "big".\nelse.\n  say "small".\nend if.')
    assert 'small' in out.getvalue()

def test_repeat_times():
    import io, contextlib
    out = io.StringIO()
    with contextlib.redirect_stdout(out):
        run('repeat 3 times.\n  say "hi".\nend repeat.')
    assert out.getvalue().count('hi') == 3

def test_function():
    import io, contextlib
    out = io.StringIO()
    with contextlib.redirect_stdout(out):
        run('define double taking n.\n  return n times 2.\nend define.\nsay double with 5.')
    assert '10' in out.getvalue()

def test_list():
    import io, contextlib
    out = io.StringIO()
    with contextlib.redirect_stdout(out):
        run('let nums be a list of 1, 2, 3.\nadd 4 to nums.\nsay the size of nums.')
    assert '4' in out.getvalue()

def test_boolean():
    import io, contextlib
    out = io.StringIO()
    with contextlib.redirect_stdout(out):
        run('let ok be yes.\nif ok is yes.\n  say "yes".\nend if.')
    assert 'yes' in out.getvalue()

if __name__ == '__main__':
    test_arithmetic()
    test_string_interpolation()
    test_if_true()
    test_if_false()
    test_repeat_times()
    test_function()
    test_list()
    test_boolean()
    print("All evaluator tests passed!")
