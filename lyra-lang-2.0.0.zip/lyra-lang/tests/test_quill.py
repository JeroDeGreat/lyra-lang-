"""
Quill Language Test Suite
Run with: python -m pytest tests/ -v
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import pytest
from lyra.evaluator import run_string, Evaluator, LyraRuntimeError
from lyra.parser import parse, ParseError
from lyra.lexer import tokenize, TT


# ─── Lexer Tests ────────────────────────────────────────────────────────────

class TestLexer:
    def test_simple_words(self):
        tokens = [t for t in tokenize("let age be 25.") if t.type not in (TT.NEWLINE,)]
        types = [t.type for t in tokens]
        assert TT.WORD in types
        assert TT.NUMBER in types
        assert TT.PERIOD in types

    def test_string_token(self):
        tokens = tokenize('say "Hello, World!".')
        strings = [t for t in tokens if t.type == TT.STRING]
        assert len(strings) == 1
        assert strings[0].value == "Hello, World!"

    def test_decimal_token(self):
        tokens = tokenize("let pi be 3.14.")
        decimals = [t for t in tokens if t.type == TT.DECIMAL]
        assert len(decimals) == 1
        assert decimals[0].value == pytest.approx(3.14)

    def test_comment_stripped(self):
        tokens = tokenize("note This is a comment.\nlet x be 1.")
        words = [t.value for t in tokens if t.type == TT.WORD]
        assert 'note' not in words
        assert 'let' in words

    def test_keywords_case_insensitive(self):
        tokens = tokenize("LET x BE 42.")
        words = [t.value for t in tokens if t.type == TT.WORD]
        assert 'let' in words
        assert 'be' in words


# ─── Parser Tests ────────────────────────────────────────────────────────────

class TestParser:
    def test_let_statement(self):
        from lyra.ast_nodes import LetStatement
        ast = parse("let x be 5.")
        assert len(ast.statements) == 1
        assert isinstance(ast.statements[0], LetStatement)
        assert ast.statements[0].names == ['x']

    def test_if_statement(self):
        from lyra.ast_nodes import IfStatement
        ast = parse("if x is 5.\n  say \"yes\".\nend if.")
        assert isinstance(ast.statements[0], IfStatement)

    def test_define_function(self):
        from lyra.ast_nodes import DefineStatement
        ast = parse("define greet taking name.\n  say name.\nend define.")
        assert isinstance(ast.statements[0], DefineStatement)
        assert ast.statements[0].name == 'greet'
        assert ast.statements[0].params == ['name']

    def test_syntax_error_message(self):
        with pytest.raises(ParseError) as exc_info:
            parse("let x be.")
        assert "line" in str(exc_info.value).lower()


# ─── Evaluator Tests ─────────────────────────────────────────────────────────

class TestVariables:
    def test_let_number(self):
        ev = Evaluator()
        ev.run(parse("let x be 42."))
        assert ev.global_env.get('x') == 42

    def test_let_string(self):
        ev = Evaluator()
        ev.run(parse('let name be "Alice".'))
        assert ev.global_env.get('name') == "Alice"

    def test_let_boolean(self):
        ev = Evaluator()
        ev.run(parse("let flag be yes."))
        assert ev.global_env.get('flag') == True

    def test_let_nothing(self):
        ev = Evaluator()
        ev.run(parse("let x be nothing."))
        assert ev.global_env.get('x') is None

    def test_set(self):
        ev = Evaluator()
        ev.run(parse("let x be 5.\nset x to 10."))
        assert ev.global_env.get('x') == 10

    def test_multiple_assignment(self):
        ev = Evaluator()
        ev.run(parse("let x, y be 1, 2."))
        assert ev.global_env.get('x') == 1
        assert ev.global_env.get('y') == 2


class TestArithmetic:
    def _eval(self, src):
        ev = Evaluator()
        ev.run(parse(src))
        return ev.global_env.get('result')

    def test_plus(self):
        assert self._eval("let result be 3 plus 4.") == 7

    def test_minus(self):
        assert self._eval("let result be 10 minus 3.") == 7

    def test_times(self):
        assert self._eval("let result be 3 times 4.") == 12

    def test_divided_by(self):
        assert self._eval("let result be 10 divided by 2.") == 5

    def test_mod(self):
        assert self._eval("let result be 10 mod 3.") == 1

    def test_power(self):
        assert self._eval("let result be 2 to the power of 8.") == 256

    def test_add_to(self):
        ev = Evaluator()
        ev.run(parse("let x be 5.\nadd 3 to x."))
        assert ev.global_env.get('x') == 8

    def test_subtract_from(self):
        ev = Evaluator()
        ev.run(parse("let x be 10.\nsubtract 3 from x."))
        assert ev.global_env.get('x') == 7

    def test_multiply_by(self):
        ev = Evaluator()
        ev.run(parse("let x be 4.\nmultiply x by 3."))
        assert ev.global_env.get('x') == 12

    def test_divide_by(self):
        ev = Evaluator()
        ev.run(parse("let x be 12.\ndivide x by 4."))
        assert ev.global_env.get('x') == 3.0

    def test_divide_by_zero(self):
        with pytest.raises(LyraRuntimeError):
            run_string("let x be 1 divided by 0.")


class TestComparisons:
    def _eval(self, src):
        ev = Evaluator()
        ev.run(parse(src))
        return ev.global_env.get('result')

    def test_is(self):
        assert self._eval("let result be 5 is 5.") == True

    def test_is_not(self):
        assert self._eval("let result be 5 is not 6.") == True

    def test_greater_than(self):
        assert self._eval("let result be 10 is greater than 5.") == True

    def test_less_than(self):
        assert self._eval("let result be 3 is less than 7.") == True

    def test_at_least(self):
        assert self._eval("let result be 5 is at least 5.") == True

    def test_at_most(self):
        assert self._eval("let result be 5 is at most 5.") == True

    def test_is_nothing(self):
        assert self._eval("let x be nothing.\nlet result be x is nothing.") == True


class TestConditionals:
    def test_if_true(self, capsys):
        run_string('if 5 is greater than 3.\n  say "yes".\nend if.')
        assert "yes" in capsys.readouterr().out

    def test_if_false(self, capsys):
        run_string('if 2 is greater than 10.\n  say "yes".\nend if.\nsay "no".')
        captured = capsys.readouterr().out
        assert "yes" not in captured
        assert "no" in captured

    def test_else(self, capsys):
        run_string('if 1 is greater than 10.\n  say "big".\nelse.\n  say "small".\nend if.')
        assert "small" in capsys.readouterr().out

    def test_elif(self, capsys):
        run_string('let x be 5.\nif x is greater than 10.\n  say "big".\nelse if x is greater than 3.\n  say "medium".\nelse.\n  say "small".\nend if.')
        assert "medium" in capsys.readouterr().out


class TestLoops:
    def test_repeat_times(self, capsys):
        run_string('repeat 3 times.\n  say "hi".\nend repeat.')
        output = capsys.readouterr().out
        assert output.count("hi") == 3

    def test_repeat_range(self, capsys):
        run_string('repeat from 1 to 5.\n  say the current count.\nend repeat.')
        output = capsys.readouterr().out
        assert "1" in output and "5" in output

    def test_while(self, capsys):
        run_string('let i be 0.\nwhile i is less than 3.\n  add 1 to i.\n  say i.\nend while.')
        output = capsys.readouterr().out
        assert "1" in output and "3" in output

    def test_for_each(self, capsys):
        run_string('let items be a list of "a", "b", "c".\nfor each item in items.\n  say item.\nend for.')
        output = capsys.readouterr().out
        assert "a" in output and "c" in output

    def test_stop_breaks_loop(self, capsys):
        run_string('repeat from 1 to 10.\n  if the current count is 3.\n    stop.\n  end if.\n  say the current count.\nend repeat.')
        output = capsys.readouterr().out
        assert "1" in output
        assert "3" not in output
        assert "4" not in output


class TestFunctions:
    def test_define_and_call(self, capsys):
        run_string('define greet taking name.\n  say "Hi, {name}!".\nend define.\ngreet with "Alice".')
        assert "Hi, Alice!" in capsys.readouterr().out

    def test_return_value(self):
        ev = Evaluator()
        ev.run(parse('define add taking a, b.\n  return a plus b.\nend define.\nlet result be add with 3, 5.'))
        assert ev.global_env.get('result') == 8

    def test_default_param(self, capsys):
        run_string('define greet taking name with default "World".\n  say "Hello, {name}!".\nend define.\ngreet.')
        assert "Hello, World!" in capsys.readouterr().out

    def test_recursive(self):
        ev = Evaluator()
        ev.run(parse('define fact taking n.\n  if n is at most 1.\n    return 1.\n  end if.\n  let prev be fact with n minus 1.\n  return n times prev.\nend define.\nlet result be fact with 5.'))
        assert ev.global_env.get('result') == 120


class TestLists:
    def test_create_list(self):
        ev = Evaluator()
        ev.run(parse('let fruits be a list of "apple", "banana", "cherry".'))
        assert ev.global_env.get('fruits') == ["apple", "banana", "cherry"]

    def test_add_to_list(self):
        ev = Evaluator()
        ev.run(parse('let items be a list of 1, 2.\nadd 3 to items.'))
        assert ev.global_env.get('items') == [1, 2, 3]

    def test_remove_from_list(self):
        ev = Evaluator()
        ev.run(parse('let items be a list of 1, 2, 3.\nremove 2 from items.'))
        assert ev.global_env.get('items') == [1, 3]

    def test_size_of(self):
        ev = Evaluator()
        ev.run(parse('let items be a list of 1, 2, 3.\nlet count be the size of items.'))
        assert ev.global_env.get('count') == 3

    def test_empty_list(self):
        ev = Evaluator()
        ev.run(parse('let items be an empty list.'))
        assert ev.global_env.get('items') == []


class TestStrings:
    def test_uppercase(self):
        ev = Evaluator()
        ev.run(parse('let s be "hello" in uppercase.'))
        assert ev.global_env.get('s') == "HELLO"

    def test_lowercase(self):
        ev = Evaluator()
        ev.run(parse('let s be "HELLO" in lowercase.'))
        assert ev.global_env.get('s') == "hello"

    def test_contains(self):
        ev = Evaluator()
        ev.run(parse('let result be "hello world" contains "world".'))
        assert ev.global_env.get('result') == True

    def test_starts_with(self):
        ev = Evaluator()
        ev.run(parse('let result be "hello" starts with "hel".'))
        assert ev.global_env.get('result') == True

    def test_split(self):
        ev = Evaluator()
        ev.run(parse('let parts be "a,b,c" split by ",".'))
        assert ev.global_env.get('parts') == ["a", "b", "c"]

    def test_interpolation(self, capsys):
        run_string('let name be "Alice".\nsay "Hello, {name}!".')
        assert "Hello, Alice!" in capsys.readouterr().out


class TestMaps:
    def test_create_map(self):
        ev = Evaluator()
        ev.run(parse('let p be a map with "name" as "Alice", "age" as 30.'))
        m = ev.global_env.get('p')
        assert m["name"] == "Alice"
        assert m["age"] == 30

    def test_map_access(self):
        ev = Evaluator()
        ev.run(parse('let p be a map with "x" as 42.\nlet v be p at "x".'))
        assert ev.global_env.get('v') == 42

    def test_map_set(self):
        ev = Evaluator()
        ev.run(parse('let p be a map with "x" as 1.\nset p at "x" to 99.'))
        assert ev.global_env.get('p')["x"] == 99


class TestErrorHandling:
    def test_try_catch(self, capsys):
        run_string('try.\n  raise error "oops".\ncatch err.\n  say "caught: {err}".\nend try.')
        assert "caught: oops" in capsys.readouterr().out

    def test_raise(self):
        with pytest.raises(LyraRuntimeError):
            run_string('raise error "bad".')

    def test_undefined_variable(self):
        with pytest.raises(LyraRuntimeError):
            run_string('say undefined_variable.')


class TestInterpolation:
    def test_current_count_in_string(self, capsys):
        run_string('repeat from 1 to 3.\n  say "count: {the current count}".\nend repeat.')
        out = capsys.readouterr().out
        assert "count: 1" in out
        assert "count: 3" in out

    def test_its_in_string(self, capsys):
        run_string('''
define class Dog.
  it has name.
  define create taking name.
    set its name to name.
  end define.
  define speak.
    say "My name is {its name}.".
  end define.
end class.
let d be a new Dog with "Rex".
call speak on d.
''')
        assert "My name is Rex." in capsys.readouterr().out


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
