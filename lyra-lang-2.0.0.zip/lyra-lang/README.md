<div align="center">

<img src="lyra-icon.svg" width="110" alt="Lyra Logo"/>

# 🪶 Lyra Programming Language

### *"Write code the way you think."*

**The world's most readable programming language.**  
**The only symbols you'll ever type are `,` and `.`**

[![Version](https://img.shields.io/badge/version-2.0.0-blue?style=flat-square)](https://github.com/lyra-lang/lyra)
[![License](https://img.shields.io/badge/license-MIT-green?style=flat-square)](LICENSE)
[![Python](https://img.shields.io/badge/python-3.10+-yellow?style=flat-square)](https://python.org)

**Created by Jero W. Grabo · Lyra Language Team**

[Download](#installation) · [Docs](docs/LANGUAGE_REFERENCE.md) · [Examples](examples/) · [Website](https://lyra-lang.org)

</div>

---

## What is Lyra?

Lyra is a complete programming language where every line reads like a plain English sentence. No braces. No semicolons. No symbols of any kind — except a **comma** to separate things and a **period** to end statements, exactly like written English.

```
let name be "Alice".
let age be 28.

if age is at least 18.
  say "Welcome, {name}!".
else.
  say "Sorry, come back later.".
end if.
```

---

## What Can Lyra Do?

| Field | Examples |
|---|---|
| 🤖 AI / Machine Learning | Naive Bayes, linear regression, k-NN, k-Means |
| 📊 Data Science | CSV analysis, statistics, normalization, charts |
| 🖥️ Desktop GUI | Dark-mode apps, charts, tables, progress bars |
| 🌐 Web | HTTP servers, REST API clients, JSON |
| 🔒 Cybersecurity | Hashing, tokens, port scanning, password tools |
| 🗄️ Database | SQLite CRUD, persistent storage |
| ⚡ Automation | File scripts, system commands, batch processing |
| 🌍 Networking | DNS, port scanning, TCP, URL tools |
| ⛓️ Blockchain | Mining, validation, transaction ledgers |
| 🎮 Games | Terminal games, interactive GUI quizzes |
| 🔗 Python Interop | Use any Python library from Lyra |

---

## Installation

### Windows

```powershell
cd "C:\Users\YourName\Downloads\lyra-lang"
powershell -ExecutionPolicy Bypass -File ".\install.ps1"
```

Then open a **new** terminal and verify:
```powershell
lyra version
```

**Common issues:**

| Problem | Fix |
|---|---|
| `lyra not recognized` | Close terminal, open a new one |
| `Script cannot be loaded` | Use `powershell -ExecutionPolicy Bypass -File ".\install.ps1"` |
| `Python not found` | Install Python from python.org — tick **Add Python to PATH** |
| Still shows old version | Run `Remove-Item -Recurse -Force "$env:APPDATA\Lyra"` then reinstall |

### Linux / Kali

```bash
chmod +x install.sh && ./install.sh
source ~/.bashrc
lyra version
```

For Kali specifically:
```bash
sudo apt install python3 python3-pip python3-tk -y
pip3 install customtkinter matplotlib
```

### macOS

```bash
./install.sh
source ~/.zshrc
lyra version
```

---

## Quick Start

```bash
lyra version              # Check version
lyra repl                 # Interactive REPL
lyra new myproject        # Create a project
lyra run myfile.lyr       # Run a program
lyra check myfile.lyr     # Check syntax only
lyra build myfile.lyr     # Build executable
```

---

## VS Code Extension

1. Install `lyra-lang.vsix` via `Ctrl+Shift+P` → `Install from VSIX`
2. Set the executable path in Settings (search `lyra`):
   ```
   C:\Users\YourName\AppData\Roaming\Lyra\bin\lyra.bat
   ```
   No quotes around it in the settings box.

---

## The Language

```
note Variables
let name be "Alice".
let score be 100.
let active be yes.
set score to 200.

note Arithmetic — English words only, no symbols
let total be price times quantity.
let half be total divided by 2.
let change be total minus paid.
let remainder be total mod 7.
let root be square root of 144.

note Conditions
if score is at least 90.
  say "Excellent!".
else if score is at least 70.
  say "Good.".
else.
  say "Keep practicing.".
end if.

note Loops
repeat 5 times.
  say "Hello!".
end repeat.

repeat from 1 to 10.
  say the current count.
end repeat.

for each item in my_list.
  say item.
end for.

while score is less than 1000.
  add 100 to score.
end while.

note Functions
define greet taking name.
  say "Hello, {name}!".
end define.

define add taking a, b.
  return a plus b.
end define.

greet with "Alice".
let result be add with 3, 5.

note Lists
let fruits be a list of "apple", "banana", "cherry".
add "mango" to fruits.
remove "banana" from fruits.
let count be the size of fruits.
let first be the first item in fruits.

note Maps
let person be a map with "name" as "Alice", "age" as 30.
let name be person at "name".
set person at "city" to "Boston".

note Classes
define class Animal.
  it has name, sound.
  define create taking name, sound.
    set its name to name.
    set its sound to sound.
  end define.
  define speak.
    say "{its name} says {its sound}!".
  end define.
end class.

let cat be a new Animal with "Whiskers", "Meow".
call speak on cat.

note Error handling
try.
  raise error "Oops!".
catch err.
  say "Caught: {err}".
end try.

note HTTP requests
let response be get "https://api.example.com/data".
let data be parse response as json.
let value be data at "field".

note Database
connect to database "app.db" as db.
execute "INSERT INTO users (name) VALUES (?)" on db with a list of "Alice".
let rows be query db with "SELECT name FROM users".

note GUI
use gui.
set theme to "dark".
open a window titled "My App" with width 800, height 600.
create a label named myLabel saying "Hello!".
create a button named myBtn saying "Click" that calls onClick.
place myLabel in window.
place myBtn in window.
show window.
```

---

## Standard Library

| Module | Load | What it gives you |
|---|---|---|
| Math | `use math.` | `pi`, `e`, sqrt, trig |
| Files | `use files.` | read, write, append, delete |
| Random | `use random.` | `random number between X and Y` |
| Time | `use time.` | current time, date, wait |
| OS | `use os.` | run shell commands |
| JSON | `use json.` | parse JSON |
| Web | `use web.` | HTTP fetch |
| GUI | `use gui.` | windows, buttons, charts, tables |
| Data | `use data.` | CSV, statistics, filtering |
| ML | `use ml.` | Naive Bayes, regression, clustering |
| Crypto | `use crypto.` | hashing, tokens, passwords |
| Net | `use net.` | DNS, ports, TCP |
| Server | `use server.` | HTTP server |
| Blockchain | `use blockchain.` | blocks, mining, validation |

---

## File Structure

```
lyra-lang/
├── lyra/                  ← Interpreter
│   ├── lexer.py           ← Tokenizer
│   ├── parser.py          ← Parser
│   ├── ast_nodes.py       ← AST
│   ├── evaluator.py       ← Interpreter
│   ├── gui/               ← GUI engine
│   └── stdlib/            ← Standard library
├── examples/
│   ├── v2/                ← Feature examples
│   ├── fields/            ← Field-specific
│   └── games/
│       └── quill_quest/   ← Teaching game
├── vscode-lyra/           ← VS Code extension
├── docs/                  ← Language reference
├── website/               ← Static website
├── install.ps1            ← Windows installer
├── install.sh             ← Linux/macOS installer
├── lyra-lang.vsix         ← VS Code extension package
└── LICENSE                ← MIT, Jero W. Grabo
```

---

## License

MIT — see [LICENSE](LICENSE)  
**Created by Jero W. Grabo · Lyra Language Team**  
*"Write code the way you think."*
