"""Lyra Standard Library module loader."""

MODULE_REGISTRY = {
    'data':       'lyra.stdlib.data',
    'ml':         'lyra.stdlib.ml',
    'crypto':     'lyra.stdlib.crypto_mod',
    'net':        'lyra.stdlib.net',
    'server':     'lyra.stdlib.web_server',
    'blockchain': 'lyra.stdlib.blockchain',
}

def load_module(name: str, env, evaluator=None):
    import importlib
    module_path = MODULE_REGISTRY.get(name.lower())
    if not module_path:
        return False
    try:
        mod = importlib.import_module(module_path)
        if hasattr(mod, '_evaluator_ref') and evaluator:
            mod._evaluator_ref = evaluator
        mod.register(env)
        if hasattr(mod, 'register_aliases'):
            try:
                mod.register_aliases(env)
            except Exception:
                pass
        return True
    except Exception as e:
        print(f"Warning: Could not load module '{name}': {e}")
        return False
