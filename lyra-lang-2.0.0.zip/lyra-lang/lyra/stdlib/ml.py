"""
Quill stdlib — ml module.
Simple machine learning without external dependencies.
Pure Python implementations of core algorithms.
Loaded by: use ml.
"""
import math, random


def register(env):

    # ── Linear Regression ────────────────────────────────────────────────

    def linear_regression(x_vals, y_vals):
        """Returns dict with slope, intercept, r_squared."""
        n = len(x_vals)
        if n < 2:
            return {'slope': 0, 'intercept': 0, 'r_squared': 0}
        x = [float(v) for v in x_vals]
        y = [float(v) for v in y_vals]
        sum_x  = sum(x)
        sum_y  = sum(y)
        sum_xy = sum(xi * yi for xi, yi in zip(x, y))
        sum_x2 = sum(xi ** 2 for xi in x)
        denom  = n * sum_x2 - sum_x ** 2
        if denom == 0:
            return {'slope': 0, 'intercept': sum_y / n, 'r_squared': 0}
        slope     = (n * sum_xy - sum_x * sum_y) / denom
        intercept = (sum_y - slope * sum_x) / n
        # R²
        y_mean = sum_y / n
        ss_tot = sum((yi - y_mean) ** 2 for yi in y)
        ss_res = sum((yi - (slope * xi + intercept)) ** 2
                     for xi, yi in zip(x, y))
        r2 = 1 - (ss_res / ss_tot) if ss_tot != 0 else 1
        return {'slope': round(slope, 6), 'intercept': round(intercept, 6),
                'r_squared': round(r2, 6)}

    def predict_linear(model, x):
        return model['slope'] * float(x) + model['intercept']

    # ── k-Nearest Neighbors ─────────────────────────────────────────────

    def knn_classify(training_data, training_labels, test_point, k=3):
        """Simple k-NN classifier. training_data is list of lists of numbers."""
        def euclidean(a, b):
            return math.sqrt(sum((float(ai) - float(bi)) ** 2
                                 for ai, bi in zip(a, b)))
        distances = [(euclidean(point, test_point), label)
                     for point, label in zip(training_data, training_labels)]
        distances.sort(key=lambda x: x[0])
        k_nearest = distances[:int(k)]
        # Majority vote
        votes = {}
        for _, label in k_nearest:
            votes[label] = votes.get(label, 0) + 1
        return max(votes, key=votes.get)

    # ── Naive Bayes (text classification) ─────────────────────────────

    def train_naive_bayes(texts, labels):
        """Train a simple Naive Bayes text classifier."""
        classes = list(set(labels))
        class_counts = {c: 0 for c in classes}
        word_counts   = {c: {} for c in classes}
        vocab = set()

        for text, label in zip(texts, labels):
            class_counts[label] = class_counts.get(label, 0) + 1
            words = str(text).lower().split()
            for w in words:
                vocab.add(w)
                word_counts[label][w] = word_counts[label].get(w, 0) + 1

        total = len(texts)
        model = {
            'classes': classes,
            'class_probs': {c: class_counts[c] / total for c in classes},
            'word_counts': word_counts,
            'class_totals': {c: sum(word_counts[c].values()) for c in classes},
            'vocab_size': len(vocab),
        }
        return model

    def predict_naive_bayes(model, text):
        words  = str(text).lower().split()
        scores = {}
        for c in model['classes']:
            score = math.log(model['class_probs'].get(c, 1e-10))
            total = model['class_totals'].get(c, 0)
            vocab = model['vocab_size']
            for w in words:
                count = model['word_counts'].get(c, {}).get(w, 0)
                score += math.log((count + 1) / (total + vocab + 1))
            scores[c] = score
        return max(scores, key=scores.get)

    # ── k-Means Clustering ──────────────────────────────────────────────

    def kmeans(data, k=3, iterations=100):
        """Simple k-Means. data is list of lists of numbers."""
        k   = int(k)
        pts = [[float(v) for v in row] for row in data]
        dim = len(pts[0])
        # Random initialization
        centroids = random.sample(pts, min(k, len(pts)))

        for _ in range(iterations):
            # Assign clusters
            assignments = []
            for p in pts:
                dists = [math.sqrt(sum((p[i] - c[i]) ** 2 for i in range(dim)))
                         for c in centroids]
                assignments.append(dists.index(min(dists)))

            # Update centroids
            new_centroids = []
            for ki in range(k):
                members = [pts[j] for j, a in enumerate(assignments) if a == ki]
                if members:
                    new_c = [sum(m[i] for m in members) / len(members)
                             for i in range(dim)]
                    new_centroids.append(new_c)
                else:
                    new_centroids.append(centroids[ki])

            if new_centroids == centroids:
                break
            centroids = new_centroids

        return {'assignments': assignments, 'centroids': centroids}

    # ── Decision tree (very simple, single split) ───────────────────────

    def train_decision_stump(features, labels, feature_index=0):
        """A single-feature decision stump."""
        fi    = int(feature_index)
        vals  = sorted(set(float(f[fi]) for f in features))
        best  = {'threshold': 0, 'accuracy': 0, 'direction': 1}

        for threshold in vals:
            for direction in (1, -1):
                correct = 0
                for feat, label in zip(features, labels):
                    pred = 1 if (float(feat[fi]) >= threshold) == (direction == 1) else 0
                    if pred == label:
                        correct += 1
                acc = correct / len(labels)
                if acc > best['accuracy']:
                    best = {'threshold': threshold,
                            'accuracy': round(acc, 4),
                            'direction': direction}
        return best

    # ── Confusion matrix ────────────────────────────────────────────────

    def confusion_matrix(actual, predicted):
        classes = sorted(set(actual))
        matrix  = {}
        for a in classes:
            matrix[a] = {}
            for p in classes:
                matrix[a][p] = 0
        for a, p in zip(actual, predicted):
            matrix[a][p] = matrix[a].get(p, 0) + 1
        return matrix

    def accuracy(actual, predicted):
        correct = sum(1 for a, p in zip(actual, predicted) if a == p)
        return round(correct / len(actual), 4) if actual else 0

    # ── Feature scaling ─────────────────────────────────────────────────

    def min_max_scale(data):
        """Scale list of numbers to 0-1 range."""
        nums = [float(x) for x in data]
        mn, mx = min(nums), max(nums)
        rng = mx - mn
        if rng == 0:
            return [0.0] * len(nums)
        return [(x - mn) / rng for x in nums]

    def train_test_split(data, labels, test_ratio=0.2):
        """Split data into training and test sets."""
        combined = list(zip(data, labels))
        random.shuffle(combined)
        split = int(len(combined) * (1 - float(test_ratio)))
        train = combined[:split]
        test  = combined[split:]
        return {
            'train_data':   [x[0] for x in train],
            'train_labels': [x[1] for x in train],
            'test_data':    [x[0] for x in test],
            'test_labels':  [x[1] for x in test],
        }

    env.define('linear regression',    linear_regression)
    env.define('predict linear',       predict_linear)
    env.define('knn classify',         knn_classify)
    env.define('train naive bayes',    train_naive_bayes)
    env.define('predict naive bayes',  predict_naive_bayes)
    env.define('kmeans',               kmeans)
    env.define('train decision stump', train_decision_stump)
    env.define('confusion matrix',     confusion_matrix)
    env.define('accuracy',             accuracy)
    env.define('min max scale',        min_max_scale)
    env.define('train test split',     train_test_split)


def register_aliases(env):
    """Register single-word aliases."""
    try:
        env.define('linearregression',  env.get('linear regression'))
        env.define('predictlinear',     env.get('predict linear'))
        env.define('knnclassify',       env.get('knn classify'))
        env.define('trainbayes',        env.get('train naive bayes'))
        env.define('predictbayes',      env.get('predict naive bayes'))
        env.define('cluster',           env.get('kmeans'))
        env.define('confusionmatrix',   env.get('confusion matrix'))
        env.define('accuracy',          env.get('accuracy'))
        env.define('scale',             env.get('min max scale'))
        env.define('splitdata',         env.get('train test split'))
    except Exception:
        pass
