"""
Quill stdlib — blockchain module.
Simple blockchain implementation for educational purposes.
Loaded by: use blockchain.
"""
import hashlib, json, time


class Block:
    def __init__(self, index, data, prev_hash):
        self.index     = index
        self.timestamp = time.time()
        self.data      = data
        self.prev_hash = prev_hash
        self.nonce     = 0
        self.hash      = self._compute_hash()

    def _compute_hash(self):
        content = json.dumps({
            'index':     self.index,
            'timestamp': self.timestamp,
            'data':      self.data,
            'prev_hash': self.prev_hash,
            'nonce':     self.nonce,
        }, sort_keys=True)
        return hashlib.sha256(content.encode()).hexdigest()

    def mine(self, difficulty=2):
        prefix = '0' * int(difficulty)
        while not self.hash.startswith(prefix):
            self.nonce += 1
            self.hash = self._compute_hash()

    def to_dict(self):
        return {
            'index':     self.index,
            'timestamp': self.timestamp,
            'data':      self.data,
            'prev_hash': self.prev_hash,
            'nonce':     self.nonce,
            'hash':      self.hash,
        }


class Blockchain:
    def __init__(self, difficulty=2):
        self.difficulty = int(difficulty)
        self.chain = [self._genesis()]

    def _genesis(self):
        b = Block(0, 'Genesis Block', '0' * 64)
        b.mine(self.difficulty)
        return b

    def last_block(self):
        return self.chain[-1]

    def add_block(self, data):
        b = Block(len(self.chain), data, self.last_block().hash)
        b.mine(self.difficulty)
        self.chain.append(b)
        return b.hash

    def is_valid(self):
        for i in range(1, len(self.chain)):
            curr = self.chain[i]
            prev = self.chain[i - 1]
            if curr.hash != curr._compute_hash():
                return False
            if curr.prev_hash != prev.hash:
                return False
        return True

    def get_chain(self):
        return [b.to_dict() for b in self.chain]


_chains = {}


def register(env):

    def create_blockchain(name='default', difficulty=2):
        _chains[str(name)] = Blockchain(difficulty)
        return f'Blockchain "{name}" created'

    def add_to_blockchain(name, data):
        bc = _chains.get(str(name))
        if not bc:
            create_blockchain(name)
            bc = _chains[str(name)]
        return bc.add_block(str(data))

    def get_blockchain(name='default'):
        bc = _chains.get(str(name))
        if not bc:
            return []
        return bc.get_chain()

    def validate_blockchain(name='default'):
        bc = _chains.get(str(name))
        if not bc:
            return False
        return bc.is_valid()

    def blockchain_length(name='default'):
        bc = _chains.get(str(name))
        return len(bc.chain) if bc else 0

    def hash_block_data(data):
        return hashlib.sha256(str(data).encode()).hexdigest()

    env.define('create blockchain',    create_blockchain)
    env.define('add to blockchain',    add_to_blockchain)
    env.define('get blockchain',       get_blockchain)
    env.define('validate blockchain',  validate_blockchain)
    env.define('blockchain length',    blockchain_length)
    env.define('hash block data',      hash_block_data)



def register_aliases(env):
    """Register single-word aliases."""
    try:
        env.define('newblockchain',      env.get('create blockchain'))
        env.define('addblock',           env.get('add to blockchain'))
        env.define('getblockchain',      env.get('get blockchain'))
        env.define('validateblockchain', env.get('validate blockchain'))
        env.define('blocklength',        env.get('blockchain length'))
        env.define('hashblock',          env.get('hash block data'))
    except Exception:
        pass
