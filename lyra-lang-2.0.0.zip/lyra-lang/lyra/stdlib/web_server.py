"""
Quill stdlib — server module.
Simple HTTP server that can be started from Quill.
Loaded by: use server.
"""
import threading
import json as _json
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs


_active_server = None
_routes = {}
_evaluator_ref = None


def register(env):
    global _routes, _evaluator_ref

    def add_route(path, handler_name):
        _routes[str(path)] = str(handler_name)

    def start_server(port=8080, host='0.0.0.0'):
        global _active_server
        port = int(port)
        host = str(host)

        class QuillHandler(BaseHTTPRequestHandler):
            def log_message(self, format, *args):
                pass  # Suppress default logging

            def do_GET(self):
                parsed = urlparse(self.path)
                path = parsed.path
                handler_name = _routes.get(path, _routes.get('*'))
                if handler_name and _evaluator_ref:
                    try:
                        fn = _evaluator_ref.global_env.get(handler_name)
                        from lyra.evaluator import Environment
                        call_env = Environment(_evaluator_ref.global_env)
                        call_env.define('request path', path)
                        call_env.define('request method', 'GET')
                        call_env.define('query string', parsed.query)
                        result = _evaluator_ref._call_function(fn, [], call_env)
                        body = str(result) if result is not None else 'OK'
                        self.send_response(200)
                        if body.strip().startswith('{') or body.strip().startswith('['):
                            self.send_header('Content-Type', 'application/json')
                        else:
                            self.send_header('Content-Type', 'text/html; charset=utf-8')
                        self.end_headers()
                        self.wfile.write(body.encode('utf-8'))
                        return
                    except Exception as e:
                        self.send_response(500)
                        self.send_header('Content-Type', 'text/plain')
                        self.end_headers()
                        self.wfile.write(f'Error: {e}'.encode('utf-8'))
                        return
                self.send_response(404)
                self.end_headers()
                self.wfile.write(b'Not Found')

            def do_POST(self):
                length = int(self.headers.get('Content-Length', 0))
                body   = self.rfile.read(length).decode('utf-8')
                parsed = urlparse(self.path)
                path   = parsed.path
                handler_name = _routes.get(f'POST:{path}',
                               _routes.get(path))
                if handler_name and _evaluator_ref:
                    try:
                        fn = _evaluator_ref.global_env.get(handler_name)
                        from lyra.evaluator import Environment
                        call_env = Environment(_evaluator_ref.global_env)
                        call_env.define('request body', body)
                        call_env.define('request path', path)
                        call_env.define('request method', 'POST')
                        result = _evaluator_ref._call_function(fn, [], call_env)
                        response = str(result) if result is not None else '{}'
                        self.send_response(200)
                        self.send_header('Content-Type', 'application/json')
                        self.end_headers()
                        self.wfile.write(response.encode('utf-8'))
                        return
                    except Exception as e:
                        self.send_response(500)
                        self.end_headers()
                        self.wfile.write(str(e).encode())
                        return
                self.send_response(404)
                self.end_headers()

        _active_server = HTTPServer((host, port), QuillHandler)
        print(f'Quill server running at http://{host}:{port}')
        _active_server.serve_forever()

    def start_server_background(port=8080, host='0.0.0.0'):
        t = threading.Thread(target=start_server, args=(port, host), daemon=True)
        t.start()
        import time; time.sleep(0.3)
        return f'Server running on port {port}'

    def stop_server():
        global _active_server
        if _active_server:
            _active_server.shutdown()
            _active_server = None

    env.define('add route',    add_route)
    env.define('start server', start_server)
    env.define('start server background', start_server_background)
    env.define('stop server',  stop_server)
    env.define('server routes', _routes)



def register_aliases(env):
    """Register single-word aliases."""
    try:
        env.define('addroute',    env.get('add route'))
        env.define('startserver', env.get('start server'))
        env.define('stopserver',  env.get('stop server'))
    except Exception:
        pass
