"""
Quill stdlib — crypto module.
Hashing, encoding, simple encryption, tokens.
No external dependencies (uses Python stdlib only).
Loaded by: use crypto.
"""
import hashlib, hmac, secrets, base64, os


def register(env):

    def hash_text(text, algorithm='sha256'):
        """Hash a string. Algorithms: md5, sha1, sha256, sha512."""
        alg = str(algorithm).lower().replace('-', '')
        h = hashlib.new(alg)
        h.update(str(text).encode('utf-8'))
        return h.hexdigest()

    def hash_file(path, algorithm='sha256'):
        """Hash a file's contents."""
        alg = str(algorithm).lower().replace('-', '')
        h = hashlib.new(alg)
        with open(str(path), 'rb') as f:
            while chunk := f.read(8192):
                h.update(chunk)
        return h.hexdigest()

    def generate_token(length=32):
        """Generate a cryptographically secure random token."""
        return secrets.token_hex(int(length))

    def generate_password(length=16):
        """Generate a secure random password."""
        alphabet = 'abcdefghijklmnopqrstuvwxyz'
        alphabet += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
        alphabet += '0123456789'
        return ''.join(secrets.choice(alphabet) for _ in range(int(length)))

    def encode_base64(text):
        """Encode text to base64."""
        return base64.b64encode(str(text).encode('utf-8')).decode('utf-8')

    def decode_base64(text):
        """Decode base64 to text."""
        try:
            return base64.b64decode(str(text)).decode('utf-8')
        except Exception as e:
            return f'Decode error: {e}'

    def hmac_sign(message, key, algorithm='sha256'):
        """Generate HMAC signature."""
        alg = str(algorithm).lower()
        sig = hmac.new(str(key).encode('utf-8'),
                       str(message).encode('utf-8'),
                       digestmod=getattr(hashlib, alg, hashlib.sha256))
        return sig.hexdigest()

    def verify_hmac(message, key, signature, algorithm='sha256'):
        """Verify an HMAC signature."""
        expected = hmac_sign(message, key, algorithm)
        return hmac.compare_digest(expected, str(signature))

    def caesar_cipher(text, shift):
        """Simple Caesar cipher (for educational purposes)."""
        result = []
        for ch in str(text):
            if ch.isalpha():
                base = ord('A') if ch.isupper() else ord('a')
                result.append(chr((ord(ch) - base + int(shift)) % 26 + base))
            else:
                result.append(ch)
        return ''.join(result)

    def xor_encrypt(text, key):
        """XOR cipher (for educational purposes)."""
        key_bytes = str(key).encode('utf-8')
        text_bytes = str(text).encode('utf-8')
        result = bytes([t ^ key_bytes[i % len(key_bytes)]
                        for i, t in enumerate(text_bytes)])
        return base64.b64encode(result).decode('utf-8')

    def xor_decrypt(ciphertext, key):
        """XOR decipher."""
        try:
            key_bytes = str(key).encode('utf-8')
            data = base64.b64decode(str(ciphertext))
            result = bytes([d ^ key_bytes[i % len(key_bytes)]
                            for i, d in enumerate(data)])
            return result.decode('utf-8')
        except Exception as e:
            return f'Decrypt error: {e}'

    def check_password_strength(password):
        """Returns strength score 0-100 and feedback."""
        pwd = str(password)
        score = 0
        feedback = []
        if len(pwd) >= 8:   score += 20
        else: feedback.append('Use at least 8 characters')
        if len(pwd) >= 12:  score += 10
        if any(c.isupper() for c in pwd): score += 20
        else: feedback.append('Add uppercase letters')
        if any(c.islower() for c in pwd): score += 20
        else: feedback.append('Add lowercase letters')
        if any(c.isdigit() for c in pwd): score += 20
        else: feedback.append('Add numbers')
        special = '!@#$%^&*()_+-=[]{}|;:,.<>?'
        if any(c in special for c in pwd): score += 10
        else: feedback.append('Add special characters')
        if len(set(pwd)) > len(pwd) * 0.6: score += 10
        if score >= 80: rating = 'Strong'
        elif score >= 60: rating = 'Good'
        elif score >= 40: rating = 'Fair'
        else: rating = 'Weak'
        return {'score': score, 'rating': rating,
                'feedback': feedback if feedback else ['Looks good!']}

    def is_valid_hash(text, hash_val, algorithm='sha256'):
        """Check if text matches a hash."""
        return hash_text(text, algorithm) == str(hash_val)

    env.define('hash text',             hash_text)
    env.define('hash file',             hash_file)
    env.define('generate token',        generate_token)
    env.define('generate password',     generate_password)
    env.define('encode base64',         encode_base64)
    env.define('decode base64',         decode_base64)
    env.define('hmac sign',             hmac_sign)
    env.define('verify hmac',           verify_hmac)
    env.define('caesar cipher',         caesar_cipher)
    env.define('xor encrypt',           xor_encrypt)
    env.define('xor decrypt',           xor_decrypt)
    env.define('check password strength', check_password_strength)
    env.define('is valid hash',         is_valid_hash)


def register_aliases(env):
    """Register single-word aliases for all crypto functions."""
    # Get the functions already registered
    try:
        env.define('hash',             env.get('hash text'))
        env.define('hashtext',         env.get('hash text'))
        env.define('hashfile',         env.get('hash file'))
        env.define('token',            env.get('generate token'))
        env.define('password',         env.get('generate password'))
        env.define('base64encode',     env.get('encode base64'))
        env.define('base64decode',     env.get('decode base64'))
        env.define('xorencrypt',       env.get('xor encrypt'))
        env.define('xordecrypt',       env.get('xor decrypt'))
        env.define('passwordstrength', env.get('check password strength'))
        env.define('caesarcipher',     env.get('caesar cipher'))
    except Exception:
        pass
