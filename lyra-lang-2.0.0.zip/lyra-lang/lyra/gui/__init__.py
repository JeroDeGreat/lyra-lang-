"""
Quill GUI Module v2.0
Professional UI using CustomTkinter (modern themed tkinter).
Falls back to standard tkinter if CustomTkinter is not installed.

CRITICAL RULE: Zero tkinter objects are created until show_window() is called.
Everything before that is stored in plain Python dicts. This prevents the
"no default root window" error.
"""
from __future__ import annotations
from typing import Any, Callable, Dict, List, Optional


# ─── Theme palette ────────────────────────────────────────────────────────────

DARK_THEME = {
    'bg':          '#1a1a2e',
    'surface':     '#16213e',
    'surface2':    '#0f3460',
    'primary':     '#4a6cf7',
    'primary_hover':'#5a7cff',
    'success':     '#00b894',
    'warning':     '#fdcb6e',
    'danger':      '#e17055',
    'text':        '#ffffff',
    'text_muted':  '#a0aec0',
    'border':      '#2d3748',
    'card':        '#1e2a4a',
}

LIGHT_THEME = {
    'bg':          '#f7f8fc',
    'surface':     '#ffffff',
    'surface2':    '#edf2f7',
    'primary':     '#4a6cf7',
    'primary_hover':'#3a5ce7',
    'success':     '#00b894',
    'warning':     '#f39c12',
    'danger':      '#e74c3c',
    'text':        '#1a1a2e',
    'text_muted':  '#718096',
    'border':      '#e2e8f0',
    'card':        '#ffffff',
}


class LyraGUI:
    """
    All configuration is stored as plain Python until show_window() is called.
    show_window() creates Tk(), then builds everything inside it.
    """

    def __init__(self, env):
        self.env        = env
        self._evaluator = None

        # Window settings
        self._title   = "Quill App"
        self._width   = 800
        self._height  = 600
        self._theme   = "dark"
        self._icon    = None

        # Widget definitions (plain dicts, NO tk objects yet)
        self._defs:   List[dict]       = []   # ordered widget definitions
        self._order:  List[str]        = []   # explicit place order
        self._layouts: Dict[str, dict] = {}   # name → layout definition
        self._events: Dict[str, str]   = {}   # "name:event" → callback_name

        # Runtime tk references (populated in show_window)
        self._vars:    Dict[str, Any] = {}
        self._widgets: Dict[str, Any] = {}
        self._root = None
        self._ctk = None   # customtkinter module if available

    # ── Pre-show configuration ─────────────────────────────────────────

    def set_theme(self, theme: str):
        self._theme = theme.lower().strip()

    def open_window(self, title: str, width: int, height: int):
        self._title  = str(title)
        self._width  = int(width)
        self._height = int(height)

    def _add_def(self, d: dict):
        self._defs.append(d)

    def create_label(self, name: str, text: str):
        self._add_def({'type': 'label', 'name': name, 'text': str(text)})

    def create_button(self, name: str, text: str,
                      callback_name: Optional[str], evaluator):
        self._evaluator = evaluator
        self._add_def({'type': 'button', 'name': name,
                       'text': str(text), 'callback': callback_name})

    def create_text_input(self, name: str, placeholder: str = ''):
        self._add_def({'type': 'entry', 'name': name,
                       'placeholder': str(placeholder)})

    def create_checkbox(self, name: str, text: str):
        self._add_def({'type': 'checkbox', 'name': name, 'text': str(text)})

    def create_toggle(self, name: str, text: str):
        self._add_def({'type': 'toggle', 'name': name, 'text': str(text)})

    def create_dropdown(self, name: str, choices: List[str]):
        self._add_def({'type': 'dropdown', 'name': name, 'choices': choices})

    def create_slider(self, name: str, min_val: float, max_val: float):
        self._add_def({'type': 'slider', 'name': name,
                       'min': min_val, 'max': max_val})

    def create_progress(self, name: str):
        self._add_def({'type': 'progress', 'name': name, 'value': 0})

    def create_table(self, name: str, columns: List[str]):
        self._add_def({'type': 'table', 'name': name, 'columns': columns,
                       'rows': []})

    def create_chart(self, chart_type: str, name: str, title: str = ''):
        self._add_def({'type': 'chart', 'name': name,
                       'chart_type': chart_type, 'title': title,
                       'labels': [], 'values': []})

    def create_layout(self, layout_type: str, name: str, title: str = ''):
        d = {'type': 'layout', 'layout_type': layout_type,
             'name': name, 'title': title, 'children': []}
        self._layouts[name] = d
        self._add_def(d)

    def add_to_layout(self, widgets: List[str], layout: str):
        if layout in self._layouts:
            self._layouts[layout]['children'].extend(widgets)
        else:
            for w in widgets:
                if w not in self._order:
                    self._order.append(w)

    def place_in_window(self, widget_names: List[str]):
        for n in widget_names:
            if n not in self._order:
                self._order.append(n)

    def add_row_to_table(self, table_name: str, values: list):
        for d in self._defs:
            if d['name'] == table_name and d['type'] == 'table':
                d['rows'].append(values)
                # If already rendered, update live
                if table_name in self._widgets:
                    self._refresh_table(table_name, d)
                return

    def set_chart_data(self, chart_name: str, labels, values):
        for d in self._defs:
            if d['name'] == chart_name and d['type'] == 'chart':
                d['labels'] = list(labels) if labels else []
                d['values'] = list(values) if values else []
                if chart_name in self._widgets:
                    self._refresh_chart(chart_name, d)
                return

    def register_event(self, widget: str, event: str, callback: str):
        self._events[f'{widget}:{event}'] = callback

    # ── Runtime setters (called after show_window) ─────────────────────

    def set_text(self, name: str, value: str):
        value = str(value)
        if name in self._vars:
            self._vars[name].set(value)
        # Update def text too for re-renders
        for d in self._defs:
            if d.get('name') == name:
                d['text'] = value

    def set_color(self, name: str, color: str):
        if name in self._widgets:
            w = self._widgets[name]
            try:
                w.configure(fg_color=color)
            except Exception:
                try:
                    w.configure(background=color)
                except Exception:
                    pass

    def set_progress_value(self, name: str, value: float):
        if name in self._widgets:
            w = self._widgets[name]
            try:
                w.set(float(value) / 100.0)
            except Exception:
                try:
                    w['value'] = float(value)
                except Exception:
                    pass
        if name in self._vars:
            self._vars[name].set(str(value))

    def get_value(self, name: str):
        if name in self._vars:
            v = self._vars[name].get()
            return v
        return ''

    def show_toast(self, message: str, duration_ms: int = 3000):
        if self._root is None:
            print(f"[Toast] {message}")
            return
        self._build_toast(message, duration_ms)

    # ── show_window — THE ONLY PLACE TK OBJECTS ARE CREATED ───────────

    def show_window(self, evaluator=None):
        if evaluator:
            self._evaluator = evaluator

        # ── Try CustomTkinter first, fall back to tkinter ──────────────
        ctk = None
        try:
            import customtkinter as ctk_mod
            ctk = ctk_mod
            ctk.set_appearance_mode(self._theme)
            ctk.set_default_color_theme("blue")
            self._ctk = ctk
        except ImportError:
            ctk = None
            self._ctk = None

        palette = DARK_THEME if self._theme == 'dark' else LIGHT_THEME

        # ── Create root ─────────────────────────────────────────────────
        if ctk:
            root = ctk.CTk()
        else:
            import tkinter as tk
            root = tk.Tk()
            root.configure(bg=palette['bg'])

        self._root = root
        root.title(self._title)
        root.geometry(f"{self._width}x{self._height}")
        root.resizable(True, True)
        root.minsize(300, 200)

        # Set up standard tkinter styling for fallback
        if not ctk:
            self._apply_tk_style(root, palette)

        # ── Scrollable main frame ───────────────────────────────────────
        if ctk:
            scroll_frame = ctk.CTkScrollableFrame(
                root,
                fg_color=palette['bg'],
                corner_radius=0
            )
            scroll_frame.pack(fill='both', expand=True, padx=0, pady=0)
            main_frame = scroll_frame
        else:
            import tkinter as tk
            canvas = tk.Canvas(root, bg=palette['bg'], highlightthickness=0)
            scrollbar = tk.Scrollbar(root, orient='vertical', command=canvas.yview)
            main_frame = tk.Frame(canvas, bg=palette['bg'])
            main_frame.bind('<Configure>',
                lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
            canvas.create_window((0, 0), window=main_frame, anchor='nw')
            canvas.configure(yscrollcommand=scrollbar.set)
            canvas.pack(side='left', fill='both', expand=True)
            scrollbar.pack(side='right', fill='y')

        self._frame = main_frame

        # ── Determine build order ───────────────────────────────────────
        order = list(self._order)
        for d in self._defs:
            if d.get('name') and d['name'] not in order:
                order.append(d['name'])

        defs_by_name = {d['name']: d for d in self._defs if d.get('name')}

        # ── Build each widget ───────────────────────────────────────────
        for name in order:
            d = defs_by_name.get(name)
            if d is None:
                continue
            self._build_widget(d, main_frame, palette)

        # ── Register env proxies ────────────────────────────────────────
        for name, var in self._vars.items():
            self.env.define(name, _WidgetProxy(name, var, self))

        # ── Start event loop ────────────────────────────────────────────
        root.mainloop()

    # ── Widget builders ────────────────────────────────────────────────

    def _build_widget(self, d: dict, parent, palette: dict):
        import tkinter as tk
        ctk = self._ctk
        wtype = d['type']
        name  = d.get('name', '')

        if wtype == 'label':
            var = tk.StringVar(master=self._root, value=d.get('text', ''))
            self._vars[name] = var
            if ctk:
                w = ctk.CTkLabel(
                    parent,
                    textvariable=var,
                    font=ctk.CTkFont(size=14),
                    text_color=palette['text'],
                    anchor='w'
                )
            else:
                w = tk.Label(parent, textvariable=var,
                             bg=palette['bg'], fg=palette['text'],
                             font=('Segoe UI', 12), anchor='w')
            w.pack(fill='x', padx=16, pady=(6, 2))
            self._widgets[name] = w

        elif wtype == 'button':
            var = tk.StringVar(master=self._root, value=d.get('text', ''))
            self._vars[name] = var
            cb_name = d.get('callback')
            ev      = self._evaluator

            def make_cmd(cb=cb_name, e=ev):
                def cmd():
                    if cb and e:
                        try:
                            fn = e.global_env.get(cb)
                            e._call_function(fn, [], e.global_env)
                        except Exception as ex:
                            print(f"Error in {cb}: {ex}")
                return cmd

            btn_text = d.get('text', '')
            if ctk:
                w = ctk.CTkButton(
                    parent,
                    text=btn_text,
                    command=make_cmd(),
                    font=ctk.CTkFont(size=13, weight='bold'),
                    height=38,
                    corner_radius=8,
                    fg_color=palette['primary'],
                    hover_color=palette['primary_hover'],
                    text_color='white',
                )
            else:
                w = tk.Button(
                    parent,
                    textvariable=var,
                    command=make_cmd(),
                    bg=palette['primary'], fg='white',
                    font=('Segoe UI', 11, 'bold'),
                    relief='flat', cursor='hand2',
                    padx=16, pady=8,
                    activebackground=palette['primary_hover'],
                    activeforeground='white',
                )
            w.pack(fill='x', padx=16, pady=4)
            self._widgets[name] = w

            # trace var changes to update button text
            def make_trace(btn=w, v=var, use_ctk=bool(ctk)):
                def on_change(*args):
                    if use_ctk:
                        btn.configure(text=v.get())
                    else:
                        btn.config(text=v.get())
                return on_change
            var.trace_add('write', make_trace())

        elif wtype == 'entry':
            var = tk.StringVar(master=self._root, value='')
            self._vars[name] = var
            ph = d.get('placeholder', '')
            if ctk:
                w = ctk.CTkEntry(
                    parent,
                    textvariable=var,
                    placeholder_text=ph,
                    font=ctk.CTkFont(size=13),
                    height=38,
                    corner_radius=8,
                    border_color=palette['border'],
                )
            else:
                w = tk.Entry(parent, textvariable=var,
                             bg=palette['surface'], fg=palette['text'],
                             font=('Segoe UI', 11),
                             insertbackground=palette['text'],
                             relief='flat', bd=2)
                if ph:
                    var.set(ph)
                    def fi(e, v=var, p=ph):
                        if v.get() == p: v.set('')
                    def fo(e, v=var, p=ph):
                        if not v.get(): v.set(p)
                    w.bind('<FocusIn>', fi)
                    w.bind('<FocusOut>', fo)
            w.pack(fill='x', padx=16, pady=4)
            self._widgets[name] = w

        elif wtype == 'checkbox':
            var = tk.BooleanVar(master=self._root, value=False)
            self._vars[name] = var
            label = d.get('text', name)
            if ctk:
                w = ctk.CTkCheckBox(
                    parent, text=label, variable=var,
                    font=ctk.CTkFont(size=13),
                    text_color=palette['text'],
                    fg_color=palette['primary'],
                    checkmark_color='white',
                )
            else:
                w = tk.Checkbutton(parent, text=label, variable=var,
                                   bg=palette['bg'], fg=palette['text'],
                                   font=('Segoe UI', 11),
                                   activebackground=palette['bg'],
                                   selectcolor=palette['primary'])
            w.pack(anchor='w', padx=16, pady=4)
            self._widgets[name] = w

        elif wtype == 'toggle':
            var = tk.BooleanVar(master=self._root, value=False)
            self._vars[name] = var
            label = d.get('text', name)
            if ctk:
                w = ctk.CTkSwitch(
                    parent, text=label, variable=var,
                    font=ctk.CTkFont(size=13),
                    text_color=palette['text'],
                    progress_color=palette['primary'],
                )
            else:
                w = tk.Checkbutton(parent, text=f"⬜ {label}", variable=var,
                                   bg=palette['bg'], fg=palette['text'],
                                   font=('Segoe UI', 11),
                                   activebackground=palette['bg'],
                                   selectcolor=palette['primary'])
            w.pack(anchor='w', padx=16, pady=4)
            self._widgets[name] = w

        elif wtype == 'dropdown':
            choices = [str(c) for c in d.get('choices', [])]
            var = tk.StringVar(master=self._root,
                               value=choices[0] if choices else '')
            self._vars[name] = var
            if ctk:
                w = ctk.CTkOptionMenu(
                    parent,
                    variable=var,
                    values=choices,
                    font=ctk.CTkFont(size=13),
                    height=36,
                    corner_radius=8,
                    fg_color=palette['surface2'],
                    button_color=palette['primary'],
                    button_hover_color=palette['primary_hover'],
                    text_color=palette['text'],
                )
            else:
                import tkinter.ttk as ttk
                w = ttk.Combobox(parent, textvariable=var, values=choices,
                                 font=('Segoe UI', 11), state='readonly')
            w.pack(fill='x', padx=16, pady=4)
            self._widgets[name] = w

        elif wtype == 'slider':
            var = tk.DoubleVar(master=self._root, value=d.get('min', 0))
            self._vars[name] = var
            mn = float(d.get('min', 0))
            mx = float(d.get('max', 100))
            if ctk:
                w = ctk.CTkSlider(
                    parent,
                    variable=var,
                    from_=mn, to=mx,
                    progress_color=palette['primary'],
                    button_color=palette['primary_hover'],
                )
            else:
                w = tk.Scale(parent, variable=var, from_=mn, to=mx,
                             orient='horizontal',
                             bg=palette['bg'], fg=palette['text'],
                             troughcolor=palette['surface2'],
                             activebackground=palette['primary'],
                             highlightthickness=0)
            w.pack(fill='x', padx=16, pady=4)
            self._widgets[name] = w

        elif wtype == 'progress':
            var = tk.DoubleVar(master=self._root, value=0)
            self._vars[name] = var
            if ctk:
                w = ctk.CTkProgressBar(
                    parent,
                    variable=var,
                    height=16,
                    corner_radius=8,
                    progress_color=palette['primary'],
                    fg_color=palette['surface2'],
                )
                w.set(0)
            else:
                import tkinter.ttk as ttk
                style = ttk.Style()
                style.configure('Quill.Horizontal.TProgressbar',
                                background=palette['primary'],
                                troughcolor=palette['surface2'])
                w = ttk.Progressbar(parent, variable=var,
                                    style='Quill.Horizontal.TProgressbar',
                                    maximum=100)
            w.pack(fill='x', padx=16, pady=4)
            self._widgets[name] = w

        elif wtype == 'table':
            self._build_table(d, parent, palette)

        elif wtype == 'chart':
            self._build_chart(d, parent, palette)

        elif wtype == 'layout':
            self._build_layout(d, parent, palette)

        elif wtype == 'separator':
            if ctk:
                import customtkinter as _ctk
                w = _ctk.CTkFrame(parent, height=2, fg_color=palette['border'])
            else:
                import tkinter as _tk
                w = _tk.Frame(parent, height=2, bg=palette['border'])
            w.pack(fill='x', padx=16, pady=8)

    def _build_table(self, d: dict, parent, palette: dict):
        import tkinter as tk
        import tkinter.ttk as ttk
        name = d['name']
        columns = [str(c) for c in d.get('columns', [])]
        rows    = d.get('rows', [])

        frame = tk.Frame(parent, bg=palette['card'], bd=0)
        frame.pack(fill='x', padx=16, pady=8)

        style = ttk.Style()
        style.configure('Quill.Treeview',
                         background=palette['card'],
                         foreground=palette['text'],
                         fieldbackground=palette['card'],
                         rowheight=28,
                         font=('Segoe UI', 11))
        style.configure('Quill.Treeview.Heading',
                         background=palette['surface2'],
                         foreground=palette['text'],
                         font=('Segoe UI', 11, 'bold'))
        style.map('Quill.Treeview',
                  background=[('selected', palette['primary'])],
                  foreground=[('selected', 'white')])

        tree = ttk.Treeview(frame, columns=columns,
                             show='headings',
                             style='Quill.Treeview',
                             height=min(len(rows) + 1, 10))

        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=120, anchor='w')

        sb = ttk.Scrollbar(frame, orient='vertical', command=tree.yview)
        tree.configure(yscrollcommand=sb.set)
        tree.pack(side='left', fill='both', expand=True)
        sb.pack(side='right', fill='y')

        for row in rows:
            tree.insert('', 'end', values=[str(v) for v in row])

        self._widgets[name] = tree
        # Store frame ref so we can re-parent
        self._widgets[f'_frame_{name}'] = frame

    def _refresh_table(self, name: str, d: dict):
        if name not in self._widgets:
            return
        tree = self._widgets[name]
        # Add only the last row
        rows = d.get('rows', [])
        if rows:
            tree.insert('', 'end', values=[str(v) for v in rows[-1]])

    def _build_chart(self, d: dict, parent, palette: dict):
        import tkinter as tk
        name = d['name']
        try:
            import matplotlib
            matplotlib.use('TkAgg')
            import matplotlib.pyplot as plt
            from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

            fig, ax = plt.subplots(figsize=(6, 3), dpi=90)
            fig.patch.set_facecolor(palette['card'])
            ax.set_facecolor(palette['card'])
            ax.tick_params(colors=palette['text_muted'])
            ax.spines['bottom'].set_color(palette['border'])
            ax.spines['left'].set_color(palette['border'])
            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)

            labels = d.get('labels', [])
            values = d.get('values', [])
            title  = d.get('title', '')
            ctype  = d.get('chart_type', 'bar')

            if labels and values:
                self._draw_chart_data(ax, ctype, labels, values, palette)

            if title:
                ax.set_title(title, color=palette['text'], fontsize=12,
                             fontweight='bold', pad=10)

            canvas = FigureCanvasTkAgg(fig, master=parent)
            canvas.draw()
            canvas.get_tk_widget().pack(fill='x', padx=16, pady=8)

            # Store fig/ax/canvas for later updates
            self._widgets[name] = {
                'fig': fig, 'ax': ax, 'canvas': canvas,
                'type': ctype, 'palette': palette
            }

        except ImportError:
            # Matplotlib not available — show placeholder
            lbl = tk.Label(parent,
                           text=f"[Chart: {name} — install matplotlib]",
                           bg=palette['card'], fg=palette['text_muted'],
                           font=('Segoe UI', 11))
            lbl.pack(padx=16, pady=8)
            self._widgets[name] = None

    def _draw_chart_data(self, ax, ctype, labels, values, palette):
        ax.clear()
        ax.set_facecolor(palette['card'])

        colors_list = [palette['primary'], palette['success'],
                       palette['warning'], palette['danger'],
                       '#a29bfe', '#fd79a8', '#00cec9', '#e17055']

        if ctype == 'bar':
            bars = ax.bar(labels, values,
                          color=colors_list[:len(labels)],
                          edgecolor='none', alpha=0.9)
            ax.set_ylabel('Value', color=palette['text_muted'], fontsize=9)

        elif ctype == 'line':
            ax.plot(labels, values, color=palette['primary'],
                    linewidth=2.5, marker='o', markersize=5,
                    markerfacecolor='white', markeredgecolor=palette['primary'])
            ax.fill_between(range(len(labels)), values,
                            alpha=0.15, color=palette['primary'])
            ax.set_xticks(range(len(labels)))
            ax.set_xticklabels(labels, rotation=0)

        elif ctype == 'pie':
            wedge_props = {'linewidth': 2, 'edgecolor': palette['card']}
            ax.pie(values, labels=labels,
                   colors=colors_list[:len(labels)],
                   autopct='%1.1f%%', pctdistance=0.8,
                   wedgeprops=wedge_props,
                   textprops={'color': palette['text'], 'fontsize': 9})

        ax.tick_params(colors=palette['text_muted'], labelsize=9)
        for spine in ax.spines.values():
            spine.set_color(palette['border'])

    def _refresh_chart(self, name: str, d: dict):
        if name not in self._widgets:
            return
        info = self._widgets[name]
        if not info or not isinstance(info, dict):
            return
        ax      = info['ax']
        canvas  = info['canvas']
        palette = info['palette']
        ctype   = info.get('type', 'bar')

        labels = d.get('labels', [])
        values = d.get('values', [])
        title  = d.get('title', '')

        self._draw_chart_data(ax, ctype, labels, values, palette)
        if title:
            ax.set_title(title, color=palette['text'], fontsize=12,
                         fontweight='bold', pad=10)
        canvas.draw()

    def _build_layout(self, d: dict, parent, palette: dict):
        import tkinter as tk
        ctk = self._ctk
        ltype    = d.get('layout_type', 'column')
        name     = d['name']
        title    = d.get('title', '')
        children = d.get('children', [])

        if ltype == 'card':
            if ctk:
                frame = ctk.CTkFrame(parent,
                                     fg_color=palette['card'],
                                     corner_radius=12)
            else:
                frame = tk.LabelFrame(parent, text=title or '',
                                      bg=palette['card'],
                                      fg=palette['text'],
                                      font=('Segoe UI', 11, 'bold'),
                                      bd=1, relief='solid')
            frame.pack(fill='x', padx=16, pady=8, ipadx=4, ipady=4)

        elif ltype in ('row',):
            frame = tk.Frame(parent, bg=palette['bg'])
            frame.pack(fill='x', padx=16, pady=4)
            # Children will be side-by-side — override pack for them
            d['_frame'] = frame
            d['_side']  = True

        else:
            frame = tk.Frame(parent, bg=palette['bg'])
            frame.pack(fill='x', padx=0, pady=0)

        if title and ltype == 'card' and ctk:
            lbl = ctk.CTkLabel(frame, text=title,
                                font=ctk.CTkFont(size=14, weight='bold'),
                                text_color=palette['text'])
            lbl.pack(anchor='w', padx=12, pady=(8, 4))

        self._widgets[name] = frame

        # Build children inside the layout frame
        defs_by_name = {d2['name']: d2 for d2 in self._defs if d2.get('name')}
        for child_name in children:
            cd = defs_by_name.get(child_name)
            if cd:
                if d.get('_side'):
                    # Row layout: pack side-by-side
                    _orig_pack = None
                    self._build_widget_in(cd, frame, palette, side='left')
                else:
                    self._build_widget(cd, frame, palette)

    def _build_widget_in(self, d: dict, parent, palette: dict, side='top'):
        """Build a widget inside a row layout with side-by-side packing."""
        import tkinter as tk
        # Temporarily patch pack calls — simpler: build then repack
        self._build_widget(d, parent, palette)
        name = d.get('name', '')
        if name in self._widgets:
            w = self._widgets[name]
            try:
                w.pack_forget()
                w.pack(side=side, fill='y', padx=4, pady=4, expand=True)
            except Exception:
                pass

    def _build_toast(self, message: str, duration_ms: int):
        import tkinter as tk
        ctk = self._ctk
        palette = DARK_THEME if self._theme == 'dark' else LIGHT_THEME
        toast = tk.Toplevel(self._root)
        toast.overrideredirect(True)
        toast.attributes('-topmost', True)

        rx = self._root.winfo_x() + self._root.winfo_width() // 2 - 150
        ry = self._root.winfo_y() + self._root.winfo_height() - 80
        toast.geometry(f'300x50+{rx}+{ry}')
        toast.configure(bg=palette['surface2'])

        lbl = tk.Label(toast, text=message,
                       bg=palette['surface2'], fg=palette['text'],
                       font=('Segoe UI', 11), pady=10)
        lbl.pack(expand=True, fill='both')
        toast.after(duration_ms, toast.destroy)

    def _apply_tk_style(self, root, palette: dict):
        """Apply custom styling to plain tkinter."""
        import tkinter.ttk as ttk
        style = ttk.Style(root)
        try:
            style.theme_use('clam')
        except Exception:
            pass
        style.configure('.',
                         background=palette['bg'],
                         foreground=palette['text'],
                         font=('Segoe UI', 11))
        style.configure('TEntry',
                         fieldbackground=palette['surface'],
                         foreground=palette['text'],
                         bordercolor=palette['border'])


class _WidgetProxy:
    """Lives in the Quill environment as the value of a widget variable."""
    def __init__(self, name: str, var, gui: 'LyraGUI'):
        self._name = name
        self._var  = var
        self._gui  = gui

    def get(self):
        try:
            return self._var.get()
        except Exception:
            return ''

    def config(self, **kwargs):
        if 'text' in kwargs and self._var:
            try:
                self._var.set(str(kwargs['text']))
            except Exception:
                pass

    def __repr__(self):
        return f'<Widget {self._name}>'
    def __str__(self):
        return self.get()
