"""
Lyra Tree-Walk Evaluator.
Walks the AST and evaluates nodes in a scoped environment.
"""
from __future__ import annotations
import re, math, os, sys
from typing import Any, Dict, List, Optional
from .ast_nodes import *


# ─── Exceptions used for control flow ────────────────────────────────────────

class ReturnException(Exception):
    def __init__(self, value): self.value = value

class BreakException(Exception): pass
class ContinueException(Exception): pass

class LyraError(Exception):
    def __init__(self, msg, line=0):
        super().__init__(msg)
        self.quill_line = line

class LyraRuntimeError(LyraError): pass


# ─── Environment (scope) ─────────────────────────────────────────────────────

class Environment:
    def __init__(self, parent: Optional[Environment] = None):
        self.vars: Dict[str, Any] = {}
        self.parent = parent

    def get(self, name: str) -> Any:
        name = name.lower()
        if name in self.vars:
            return self.vars[name]
        if self.parent:
            return self.parent.get(name)
        raise LyraRuntimeError(f'I do not know what "{name}" is. Did you forget to declare it with "let"?')

    def set(self, name: str, value: Any):
        name = name.lower()
        self.vars[name] = value

    def assign(self, name: str, value: Any):
        """Assign to existing variable in current or parent scope."""
        name = name.lower()
        if name in self.vars:
            self.vars[name] = value
            return
        if self.parent:
            try:
                self.parent.assign(name, value)
                return
            except LyraRuntimeError:
                pass
        # Variable not found — create it in current scope
        self.vars[name] = value

    def define(self, name: str, value: Any):
        self.vars[name.lower()] = value


# ─── Lyra function objects ───────────────────────────────────────────────────

class LyraFunction:
    def __init__(self, name, params, defaults, body, closure):
        self.name = name
        self.params = params
        self.defaults = defaults
        self.body = body
        self.closure = closure

    def __repr__(self):
        return f"<function {self.name}>"


class LyraClass:
    def __init__(self, name, parent, attributes, methods, closure):
        self.name = name
        self.parent = parent
        self.attributes = attributes
        self.methods = {m.name: m for m in methods}
        self.closure = closure

    def __repr__(self):
        return f"<class {self.name}>"


class LyraInstance:
    def __init__(self, klass: LyraClass):
        self.klass = klass
        self.attrs: Dict[str, Any] = {}

    def __repr__(self):
        return f"<{self.klass.name} object>"


# ─── Evaluator ───────────────────────────────────────────────────────────────

class Evaluator:
    def __init__(self):
        self.global_env = Environment()
        self._setup_builtins()
        self.current_count = 0   # used by 'the current count' in loops
        self.loaded_modules: Dict[str, Any] = {}
        self._current_instance: Optional[LyraInstance] = None

    def _setup_builtins(self):
        g = self.global_env
        g.define('pi', math.pi)
        g.define('e', math.e)
        g.define('true', True)
        g.define('false', False)
        g.define('yes', True)
        g.define('no', False)
        g.define('nothing', None)

    def run(self, program: Program) -> Any:
        return self.exec_block(program.statements, self.global_env)

    def exec_block(self, stmts: List[Node], env: Environment) -> Any:
        result = None
        for stmt in stmts:
            result = self.exec(stmt, env)
        return result

    def exec(self, node: Node, env: Environment) -> Any:
        if node is None:
            return None

        t = type(node)

        if t == LetStatement:     return self.exec_let(node, env)
        if t == SetStatement:     return self.exec_set(node, env)
        if t == SetItemStatement: return self.exec_set_item(node, env)
        if t == SetPropertyStatement: return self.exec_set_property(node, env)
        if t == SetTextStatement: return self.exec_set_text(node, env)
        if t == SayStatement:     return self.exec_say(node, env)
        if t == AskStatement:     return self.exec_ask(node, env)
        if t == IfStatement:      return self.exec_if(node, env)
        if t == RepeatTimesStatement: return self.exec_repeat_times(node, env)
        if t == RepeatRangeStatement: return self.exec_repeat_range(node, env)
        if t == WhileStatement:   return self.exec_while(node, env)
        if t == ForEachStatement: return self.exec_for_each(node, env)
        if t == DefineStatement:  return self.exec_define(node, env)
        if t == DefineClassStatement: return self.exec_define_class(node, env)
        if t == ReturnStatement:  return self.exec_return(node, env)
        if t == ExprStatement:
            result = self.eval(node.expr, env)
            # If a bare name resolves to a function, call it with no arguments
            # e.g.  "greet."  calls greet() rather than just reading the value
            if isinstance(result, LyraFunction):
                self._call_function(result, [], env)
            return None
        if t == TryStatement:     return self.exec_try(node, env)
        if t == RaiseStatement:   return self.exec_raise(node, env)
        if t == UseStatement:     return self.exec_use(node, env)
        if t == AddToStatement:   return self.exec_add_to(node, env)
        if t == SubtractFromStatement: return self.exec_subtract_from(node, env)
        if t == MultiplyByStatement: return self.exec_multiply_by(node, env)
        if t == DivideByStatement:   return self.exec_divide_by(node, env)
        if t == RemoveFromStatement: return self.exec_remove_from(node, env)
        if t == WriteFileStatement:  return self.exec_write_file(node, env)
        if t == DeleteFileStatement: return self.exec_delete_file(node, env)
        if t == StopStatement:    raise BreakException()
        if t == SkipStatement:    raise ContinueException()
        if t == CallOnStatement:  return self.exec_call_on(node, env)

        # GUI statements
        if t.__name__ == 'OpenWindowStatement':   return self.exec_open_window(node, env)
        if t.__name__ == 'CreateWidgetStatement': return self.exec_create_widget(node, env)
        if t.__name__ == 'PlaceInWindowStatement': return self.exec_place_in_window(node, env)
        if t.__name__ == 'ShowWindowStatement':   return self.exec_show_window(node, env)
        if t.__name__ == 'WhenStatement':         return self.exec_when(node, env)

        return None

    # ─── Statement executors ─────────────────────────────────────────────

    def exec_let(self, node: LetStatement, env: Environment):
        values = [self.eval(v, env) for v in node.values]
        # Extend values if fewer than names
        while len(values) < len(node.names):
            values.append(None)
        for name, val in zip(node.names, values):
            env.define(name, val)

    def exec_set(self, node: SetStatement, env: Environment):
        val = self.eval(node.value, env)
        env.assign(node.name, val)

    def exec_set_item(self, node: SetItemStatement, env: Environment):
        key = self.eval(node.key, env)
        val = self.eval(node.value, env)
        container = env.get(node.target)
        if node.is_map:
            if isinstance(container, dict):
                container[key] = val
            else:
                raise LyraRuntimeError(f'"{node.target}" is not a map.', node.line)
        else:
            if isinstance(container, list):
                idx = int(key) - 1  # Lyra lists are 1-indexed
                if 0 <= idx < len(container):
                    container[idx] = val
                else:
                    raise LyraRuntimeError(f'List index {key} is out of range.', node.line)
            else:
                raise LyraRuntimeError(f'"{node.target}" is not a list.', node.line)

    def exec_set_property(self, node: SetPropertyStatement, env: Environment):
        val = self.eval(node.value, env)
        if self._current_instance:
            self._current_instance.attrs[node.prop] = val
        else:
            env.assign(node.prop, val)

    def exec_set_text(self, node: SetTextStatement, env: Environment):
        val = self._interpolate(self.eval(node.value, env), env)
        # Try GUI system first
        try:
            gui = env.get('__gui__')
            gui.set_text(node.widget, val)
            return
        except Exception:
            pass
        # Fallback: plain variable / tkinter widget
        try:
            widget = env.get(node.widget)
            if hasattr(widget, 'config'):
                widget.config(text=str(val))
            else:
                env.assign(f'__text_{node.widget}__', val)
        except Exception:
            env.assign(f'__text_{node.widget}__', val)

    def exec_say(self, node: SayStatement, env: Environment):
        val = self._interpolate(self.eval(node.value, env), env)
        if node.followed_by:
            extra = self._interpolate(self.eval(node.followed_by, env), env)
            print(str(val) + str(extra))
        else:
            print(val)

    def exec_ask(self, node: AskStatement, env: Environment):
        prompt = self.eval(node.prompt, env)
        raw = input(str(prompt) + ' ')
        if node.type_annotation in ('number', 'integer', 'int'):
            try:
                val = int(raw)
            except ValueError:
                try:
                    val = float(raw)
                except ValueError:
                    val = raw
        elif node.type_annotation in ('decimal', 'float'):
            try:
                val = float(raw)
            except ValueError:
                val = raw
        elif node.type_annotation in ('truth', 'boolean', 'bool'):
            val = raw.lower() in ('yes', 'true', '1', 'y')
        else:
            val = raw
        env.assign(node.variable, val)

    def exec_if(self, node: IfStatement, env: Environment):
        if self._truthy(self.eval(node.condition, env)):
            return self.exec_block(node.then_body, Environment(env))
        for cond, body in node.elif_clauses:
            if self._truthy(self.eval(cond, env)):
                return self.exec_block(body, Environment(env))
        if node.else_body:
            return self.exec_block(node.else_body, Environment(env))

    def exec_repeat_times(self, node: RepeatTimesStatement, env: Environment):
        count = int(self.eval(node.count, env))
        for i in range(1, count + 1):
            self.current_count = i
            loop_env = Environment(env)
            loop_env.define('current count', i)
            try:
                self.exec_block(node.body, loop_env)
            except BreakException:
                break
            except ContinueException:
                continue

    def exec_repeat_range(self, node: RepeatRangeStatement, env: Environment):
        start = int(self.eval(node.start, env))
        end = int(self.eval(node.end, env))
        for i in range(start, end + 1):
            self.current_count = i
            loop_env = Environment(env)
            loop_env.define('current count', i)
            try:
                self.exec_block(node.body, loop_env)
            except BreakException:
                break
            except ContinueException:
                continue

    def exec_while(self, node: WhileStatement, env: Environment):
        while self._truthy(self.eval(node.condition, env)):
            loop_env = Environment(env)
            try:
                self.exec_block(node.body, loop_env)
            except BreakException:
                break
            except ContinueException:
                continue

    def exec_for_each(self, node: ForEachStatement, env: Environment):
        items = self.eval(node.iterable, env)
        if isinstance(items, dict):
            items = list(items.keys())
        elif not isinstance(items, (list, str)):
            raise LyraRuntimeError(f'Cannot iterate over this value.', node.line)
        for item in items:
            loop_env = Environment(env)
            loop_env.define(node.variable, item)
            try:
                self.exec_block(node.body, loop_env)
            except BreakException:
                break
            except ContinueException:
                continue

    def exec_define(self, node: DefineStatement, env: Environment):
        fn = LyraFunction(node.name, node.params, node.defaults, node.body, env)
        env.define(node.name, fn)

    def exec_define_class(self, node: DefineClassStatement, env: Environment):
        klass = LyraClass(node.name, node.parent, node.attributes, node.methods, env)
        env.define(node.name, klass)

    def exec_return(self, node: ReturnStatement, env: Environment):
        val = self.eval(node.value, env) if node.value else None
        raise ReturnException(val)

    def exec_try(self, node: TryStatement, env: Environment):
        try:
            self.exec_block(node.try_body, Environment(env))
        except (LyraError, LyraRuntimeError, Exception) as e:
            catch_env = Environment(env)
            catch_env.define(node.error_var, str(e))
            self.exec_block(node.catch_body, catch_env)

    def exec_raise(self, node: RaiseStatement, env: Environment):
        msg = self.eval(node.message, env)
        raise LyraRuntimeError(str(msg), node.line)

    def exec_use(self, node: UseStatement, env: Environment):
        self._load_module(node.module, node.alias or node.module, node.language, env)

    def exec_add_to(self, node: AddToStatement, env: Environment):
        val = self.eval(node.value, env)
        try:
            container = env.get(node.target)
            if isinstance(container, list):
                container.append(val)
            elif isinstance(container, (int, float)):
                env.assign(node.target, container + val)
            else:
                env.assign(node.target, container + val)
        except LyraRuntimeError:
            # target doesn't exist; treat as arithmetic initializer
            env.assign(node.target, val)

    def exec_subtract_from(self, node: SubtractFromStatement, env: Environment):
        val = self.eval(node.value, env)
        current = env.get(node.target)
        env.assign(node.target, current - val)

    def exec_multiply_by(self, node: MultiplyByStatement, env: Environment):
        val = self.eval(node.value, env)
        current = env.get(node.target)
        env.assign(node.target, current * val)

    def exec_divide_by(self, node: DivideByStatement, env: Environment):
        val = self.eval(node.value, env)
        current = env.get(node.target)
        if val == 0:
            raise LyraRuntimeError('I cannot divide by zero.', node.line)
        env.assign(node.target, current / val)

    def exec_remove_from(self, node: RemoveFromStatement, env: Environment):
        val = self.eval(node.value, env)
        container = env.get(node.target)
        if isinstance(container, list):
            try:
                container.remove(val)
            except ValueError:
                pass  # Value not in list — silently ignore
        elif isinstance(container, dict):
            container.pop(val, None)
        else:
            raise LyraRuntimeError(f'Cannot remove from this type.', node.line)

    def exec_write_file(self, node: WriteFileStatement, env: Environment):
        content = str(self.eval(node.content, env))
        fname = str(self.eval(node.filename, env))
        with open(fname, node.mode, encoding='utf-8') as f:
            f.write(content)

    def exec_delete_file(self, node: DeleteFileStatement, env: Environment):
        fname = str(self.eval(node.filename, env))
        if os.path.exists(fname):
            os.remove(fname)

    def exec_call_on(self, node: CallOnStatement, env: Environment):
        args = [self.eval(a, env) for a in node.args]
        obj = env.get(node.obj)
        if isinstance(obj, LyraInstance):
            return self._call_method(obj, node.method, args, env)
        # Python object interop
        method = getattr(obj, node.method, None)
        if callable(method):
            return method(*args)
        raise LyraRuntimeError(f'"{node.obj}" has no method "{node.method}".', node.line)

    # ─── Expression evaluators ───────────────────────────────────────────

    def eval(self, node: Node, env: Environment) -> Any:
        if node is None:
            return None
        t = type(node)

        if t == NumberLiteral:  return node.value
        if t == DecimalLiteral: return node.value
        if t == StringLiteral:  return node.value
        if t == BoolLiteral:    return node.value
        if t == NothingLiteral: return None
        if t == VariableRef:    return env.get(node.name)
        if t == ItsRef:
            if self._current_instance:
                return self._current_instance.attrs.get(node.prop)
            return env.get(node.prop)
        if t == CurrentCount:   return self.current_count

        if t == BinaryOp:       return self.eval_binary(node, env)
        if t == UnaryOp:        return self.eval_unary(node, env)
        if t == CompareOp:      return self.eval_compare(node, env)
        if t == LogicalOp:      return self.eval_logical(node, env)
        if t == FunctionCall:   return self.eval_call(node, env)
        if t == MethodCall:     return self.eval_method_call(node, env)
        if t == ListLiteral:    return [self.eval(i, env) for i in node.items]
        if t == MapLiteral:     return {self.eval(k, env): self.eval(v, env) for k, v in node.pairs}

        if t == ListAccess:     return self.eval_list_access(node, env)
        if t == MapAccess:      return self.eval_map_access(node, env)
        if t == SizeOf:         return self._size_of(self.eval(node.target, env))
        if t == LengthOf:       return self._size_of(self.eval(node.target, env))
        if t == StringOp:       return self.eval_string_op(node, env)
        if t == MathExpr:       return self.eval_math_expr(node, env)
        if t == TypeOf:
            v = self.eval(node.target, env)
            return self._type_name(v)
        if t == ToNumber:
            v = self.eval(node.target, env)
            try: return int(v)
            except: return float(v)
        if t == ToText:
            return str(self.eval(node.target, env))
        if t == ToTruth:
            return self._truthy(self.eval(node.target, env))
        if t == NewObject:      return self.eval_new_object(node, env)
        if t == InlineFunction:
            return LyraFunction('<lambda>', node.params, {}, [ReturnStatement(value=node.body)], env)
        if t == FetchExpr:      return self.eval_fetch(node, env)
        if t == ParseJsonExpr:  return self.eval_parse_json(node, env)
        if t == FileContentExpr:
            fname = str(self.eval(node.filename, env))
            with open(fname, 'r', encoding='utf-8') as f:
                return f.read()
        if t == FileExistsExpr:
            fname = str(self.eval(node.filename, env))
            return os.path.exists(fname)
        if t == ValueOf:
            try:
                w = env.get(node.widget)
                if hasattr(w, 'get'):
                    return w.get()
                return env.get(f'__text_{node.widget}__')
            except Exception:
                return ''

        # RandomBetweenExpr
        if t.__name__ == 'RandomBetweenExpr':
            import random
            low  = int(self.eval(node.low,  env))
            high = int(self.eval(node.high, env))
            return random.randint(low, high)

        raise LyraRuntimeError(f'I do not know how to evaluate {t.__name__}.', node.line)

    def eval_binary(self, node: BinaryOp, env: Environment) -> Any:
        l = self.eval(node.left, env)
        r = self.eval(node.right, env)
        op = node.op
        if op == '+':
            if isinstance(l, str) or isinstance(r, str):
                return str(l) + str(r)
            return l + r
        if op == '-': return l - r
        if op == '*': return l * r
        if op == '/':
            if r == 0:
                raise LyraRuntimeError('I cannot divide by zero.', node.line)
            result = l / r
            return int(result) if isinstance(l, int) and isinstance(r, int) and result == int(result) else result
        if op == '%': return l % r
        if op == '**': return l ** r
        raise LyraRuntimeError(f'Unknown operator "{op}".', node.line)

    def eval_unary(self, node: UnaryOp, env: Environment) -> Any:
        v = self.eval(node.operand, env)
        if node.op == 'neg': return -v
        if node.op == 'not': return not self._truthy(v)
        raise LyraRuntimeError(f'Unknown unary operator "{node.op}".', node.line)

    def eval_compare(self, node: CompareOp, env: Environment) -> Any:
        l = self.eval(node.left, env)
        r = self.eval(node.right, env)
        op = node.op
        if op == '==':         return l == r
        if op == '!=':         return l != r
        if op == '>':          return l > r
        if op == '<':          return l < r
        if op == '>=':         return l >= r
        if op == '<=':         return l <= r
        if op == 'is_nothing': return l is None
        raise LyraRuntimeError(f'Unknown comparison "{op}".', node.line)

    def eval_logical(self, node: LogicalOp, env: Environment) -> Any:
        l = self.eval(node.left, env)
        if node.op == 'and':
            return self._truthy(l) and self._truthy(self.eval(node.right, env))
        if node.op == 'or':
            return self._truthy(l) or self._truthy(self.eval(node.right, env))
        raise LyraRuntimeError(f'Unknown logical op "{node.op}".', node.line)

    def eval_call(self, node: FunctionCall, env: Environment) -> Any:
        name = node.name
        args = [self.eval(a, env) for a in node.args]

        # Built-in functions
        if name == 'say':
            print(' '.join(str(a) for a in args))
            return None
        if name in ('size of', '__size_of__'):
            return self._size_of(args[0]) if args else 0
        if name == 'random number':
            import random
            if len(args) >= 2:
                return random.randint(int(args[0]), int(args[1]))
            return random.random()
        if name in ('round', 'floor', 'ceiling', 'ceil', 'abs', 'sqrt'):
            v = args[0] if args else 0
            return getattr(math, name if name != 'ceiling' else 'ceil')(v)
        if name == '__run_command__':
            import subprocess
            result = subprocess.run(args[0], shell=True, capture_output=True, text=True)
            return result.stdout.strip()

        # Look up in environment
        fn = env.get(name)
        return self._call_function(fn, args, env, node.line)

    def eval_method_call(self, node: MethodCall, env: Environment) -> Any:
        obj = env.get(node.obj)
        args = [self.eval(a, env) for a in node.args]
        if isinstance(obj, LyraInstance):
            return self._call_method(obj, node.method, args, env)
        method = getattr(obj, node.method, None)
        if callable(method):
            return method(*args)
        raise LyraRuntimeError(f'No method "{node.method}" on "{node.obj}".', node.line)

    def eval_list_access(self, node: ListAccess, env: Environment) -> Any:
        lst = self.eval(node.list_expr, env)
        idx = self.eval(node.index, env)
        if not isinstance(lst, list):
            raise LyraRuntimeError('I expected a list here.', node.line)
        if idx == 'first': return lst[0] if lst else None
        if idx == 'last':  return lst[-1] if lst else None
        i = int(idx) - 1  # 1-indexed
        if 0 <= i < len(lst):
            return lst[i]
        raise LyraRuntimeError(f'List index {idx} is out of range.', node.line)

    def eval_map_access(self, node: MapAccess, env: Environment) -> Any:
        m = self.eval(node.map_expr, env)
        k = self.eval(node.key, env)
        if isinstance(m, dict):
            return m.get(k)
        raise LyraRuntimeError('I expected a map here.', node.line)

    def eval_string_op(self, node: StringOp, env: Environment) -> Any:
        target = self.eval(node.target, env)
        s = str(target)
        op = node.op
        if op == 'upper':      return s.upper()
        if op == 'lower':      return s.lower()
        if op == 'trim':       return s.strip()
        if op == 'length':     return len(s)
        if op == 'join':
            sep = str(self.eval(node.arg, env))
            if isinstance(target, list):
                return sep.join(str(x) for x in target)
            return s + sep
        if op == 'split':
            sep = self.eval(node.arg, env)
            if isinstance(sep, str):
                if sep == 'a new line' or sep == '\n':
                    return s.split('\n')
                return s.split(sep)
            return list(s)
        if op == 'contains':
            arg = str(self.eval(node.arg, env))
            return arg in s
        if op == 'starts_with':
            arg = str(self.eval(node.arg, env))
            return s.startswith(arg)
        if op == 'ends_with':
            arg = str(self.eval(node.arg, env))
            return s.endswith(arg)
        if op == 'replace':
            old = str(self.eval(node.arg, env))
            new = str(self.eval(node.arg2, env))
            return s.replace(old, new)
        raise LyraRuntimeError(f'Unknown string operation "{op}".', node.line)

    def eval_math_expr(self, node: MathExpr, env: Environment) -> Any:
        v = self.eval(node.operand, env)
        op = node.op
        if op == 'sqrt':    return math.sqrt(v)
        if op == 'abs':     return abs(v)
        if op == 'round':   return round(v)
        if op == 'floor':   return math.floor(v)
        if op == 'ceil':    return math.ceil(v)
        if op == 'power':
            exp = self.eval(node.arg, env)
            return v ** exp
        if op == 'mod':
            arg = self.eval(node.arg, env)
            return v % arg
        raise LyraRuntimeError(f'Unknown math operation "{op}".', node.line)

    def eval_new_object(self, node: NewObject, env: Environment) -> Any:
        klass = env.get(node.class_name)
        if not isinstance(klass, LyraClass):
            raise LyraRuntimeError(f'"{node.class_name}" is not a class.', node.line)
        instance = LyraInstance(klass)
        args = [self.eval(a, env) for a in node.args]
        # Call 'create' constructor if defined
        if 'create' in klass.methods:
            self._call_method(instance, 'create', args, env)
        return instance

    def eval_fetch(self, node: FetchExpr, env: Environment) -> Any:
        url = str(self.eval(node.url, env))
        try:
            import urllib.request
            with urllib.request.urlopen(url) as resp:
                return resp.read().decode('utf-8')
        except Exception as e:
            raise LyraRuntimeError(f'Could not fetch "{url}": {e}', node.line)

    def eval_parse_json(self, node: ParseJsonExpr, env: Environment) -> Any:
        import json
        text = self.eval(node.target, env)
        try:
            return json.loads(str(text))
        except Exception as e:
            raise LyraRuntimeError(f'Could not parse JSON: {e}', node.line)

    # ─── Function calling ────────────────────────────────────────────────

    def _call_function(self, fn, args: List[Any], env: Environment, line: int = 0) -> Any:
        if callable(fn) and not isinstance(fn, LyraFunction):
            return fn(*args)

        if not isinstance(fn, LyraFunction):
            raise LyraRuntimeError(f'This is not a function: {fn!r}', line)

        fn_env = Environment(fn.closure)
        for i, param in enumerate(fn.params):
            if i < len(args):
                fn_env.define(param, args[i])
            elif param in fn.defaults:
                fn_env.define(param, self.eval(fn.defaults[param], env))
            else:
                fn_env.define(param, None)

        try:
            self.exec_block(fn.body, fn_env)
        except ReturnException as ret:
            return ret.value
        return None

    def _call_method(self, instance: LyraInstance, method: str, args: List[Any], env: Environment) -> Any:
        klass = instance.klass
        # Search up the hierarchy
        m = klass.methods.get(method)
        if m is None and klass.parent:
            try:
                parent_class = env.get(klass.parent)
                if isinstance(parent_class, LyraClass):
                    m = parent_class.methods.get(method)
            except Exception:
                pass
        if m is None:
            raise LyraRuntimeError(f'Object has no method "{method}".', 0)

        fn = LyraFunction(method, m.params, m.defaults, m.body, klass.closure)
        prev_instance = self._current_instance
        self._current_instance = instance
        try:
            result = self._call_function(fn, args, env)
        finally:
            self._current_instance = prev_instance
        return result

    # ─── Module loading ──────────────────────────────────────────────────

    def _load_module(self, module: str, alias: str, language: Optional[str], env: Environment):
        mod_lower = module.lower()

        if language in ('python', 'py'):
            try:
                import importlib
                m = importlib.import_module(module)
                env.define(alias, m)
            except ImportError as e:
                raise LyraRuntimeError(f'Could not load Python module "{module}": {e}')
            return

        # Standard library modules
        stdlib_map = {
            'math':     self._load_math,
            'files':    self._load_files,
            'time':     self._load_time,
            'random':   self._load_random,
            'os':       self._load_os,
            'json':     self._load_json,
            'web':      self._load_web,
            'gui':      self._load_gui,
        }
        if mod_lower in stdlib_map:
            stdlib_map[mod_lower](alias, env)
        else:
            # Try to import as Python module
            try:
                import importlib
                m = importlib.import_module(mod_lower)
                env.define(alias, m)
            except ImportError:
                pass  # Silently ignore unknown modules

    def _load_math(self, alias, env):
        env.define('pi', math.pi)
        env.define('e', math.e)

    def _load_files(self, alias, env):
        pass  # File I/O is handled in statement evaluators

    def _load_time(self, alias, env):
        import datetime
        env.define('current time', str(datetime.datetime.now().time()))
        env.define('current date', str(datetime.date.today()))

    def _load_random(self, alias, env):
        import random
        env.define('random number', lambda: random.random())

    def _load_os(self, alias, env):
        env.define('current folder', os.getcwd())

    def _load_json(self, alias, env):
        import json
        env.define('json', json)

    def _load_web(self, alias, env):
        pass  # Web is handled via FetchExpr

    def _load_gui(self, alias, env):
        try:
            from .gui import LyraGUI
            gui = LyraGUI(env)
            gui._evaluator = self          # so callbacks can call Lyra functions
            env.define('__gui__', gui)
        except Exception as ex:
            print(f"Warning: GUI module could not load: {ex}")

    # ─── Utilities ───────────────────────────────────────────────────────

    def _truthy(self, v: Any) -> bool:
        if v is None:           return False
        if isinstance(v, bool): return v
        if isinstance(v, (int, float)): return v != 0
        if isinstance(v, str):  return len(v) > 0
        if isinstance(v, list): return len(v) > 0
        if isinstance(v, dict): return len(v) > 0
        return True

    def _size_of(self, v: Any) -> int:
        if v is None:           return 0
        if isinstance(v, (list, dict, str)): return len(v)
        return 1

    def _type_name(self, v: Any) -> str:
        if v is None:           return 'nothing'
        if isinstance(v, bool): return 'truth'
        if isinstance(v, int):  return 'number'
        if isinstance(v, float): return 'decimal'
        if isinstance(v, str):  return 'text'
        if isinstance(v, list): return 'list'
        if isinstance(v, dict): return 'map'
        if isinstance(v, LyraFunction): return 'function'
        if isinstance(v, LyraClass):    return 'class'
        if isinstance(v, LyraInstance): return v.klass.name
        return type(v).__name__

    def _interpolate(self, val: Any, env: Environment) -> str:
        """Replace {expr} in strings — supports variables, 'its X', 'the current count', 'the size of X'."""
        s = str(val)
        def replacer(m):
            raw = m.group(1).strip().lower()
            try:
                # 'the current count'
                if raw in ('the current count', 'current count'):
                    return str(self.current_count)
                # 'its PROP'
                if raw.startswith('its '):
                    prop = raw[4:].strip()
                    if self._current_instance:
                        return str(self._current_instance.attrs.get(prop, ''))
                    return m.group(0)
                # 'the size of X'
                if raw.startswith('the size of '):
                    varname = raw[12:].strip()
                    v = env.get(varname)
                    return str(self._size_of(v))
                # Simple variable name (may contain spaces for multi-word)
                return str(env.get(raw))
            except Exception:
                return m.group(0)
        return re.sub(r'\{([^}]+)\}', replacer, s)


    # ─── GUI executors ───────────────────────────────────────────────────

    def _get_gui(self, env: Environment):
        """Get or create the GUI instance."""
        try:
            return env.get('__gui__')
        except Exception:
            from .gui import LyraGUI
            gui = LyraGUI(env)
            gui._evaluator = self
            env.define('__gui__', gui)
            return gui

    def exec_open_window(self, node, env: Environment):
        gui   = self._get_gui(env)
        title  = self._interpolate(self.eval(node.title,  env), env) if node.title  else 'Lyra App'
        width  = int(self.eval(node.width,  env)) if node.width  else 400
        height = int(self.eval(node.height, env)) if node.height else 300
        gui.open_window(title, width, height)

    def exec_create_widget(self, node, env: Environment):
        gui  = self._get_gui(env)
        wt   = node.widget_type.lower().strip()
        name = node.name
        text = self._interpolate(self.eval(node.text, env), env) if node.text else ''

        if 'label' in wt:
            gui.create_label(name, text)
        elif 'button' in wt:
            gui.create_button(name, text, node.callback, self)
        elif 'input' in wt or 'entry' in wt or 'text' in wt:
            placeholder = self._interpolate(self.eval(node.placeholder, env), env) \
                          if node.placeholder else text
            gui.create_text_input(name, placeholder)
        elif 'checkbox' in wt or 'check' in wt:
            gui.create_checkbox(name, text)
        else:
            # Unknown widget type — create as label
            gui.create_label(name, text)

    def exec_place_in_window(self, node, env: Environment):
        gui = self._get_gui(env)
        gui.place_in_window(node.widgets)

    def exec_show_window(self, node, env: Environment):
        gui = self._get_gui(env)
        gui.show_window(self)   # blocks until window is closed

    def exec_when(self, node, env: Environment):
        # 'when' registers an event handler — store it so the GUI can call it
        gui = self._get_gui(env)
        body_stmts = node.body
        evaluator  = self
        def handler():
            evaluator.exec_block(body_stmts, env)
        gui._event_handlers = getattr(gui, '_event_handlers', {})
        gui._event_handlers[f'{node.widget}:{node.event}'] = handler


def run_string(source: str) -> Any:
    """Public API: run Lyra source string and return last value."""
    from .parser import parse
    ast = parse(source)
    ev = Evaluator()
    try:
        return ev.run(ast)
    except ReturnException as r:
        return r.value

# ════════════════════════════════════════════════════════════════════════════
# Lyra 2.0 — Evaluator extensions
# ════════════════════════════════════════════════════════════════════════════

_orig_exec = Evaluator.exec

def _new_exec(self, node, env):
    if node is None:
        return None
    tname = type(node).__name__

    if tname == 'IncludeStatement':
        return self._exec_include(node, env)
    if tname == 'SetThemeStatement':
        try:
            gui = self._get_gui(env)
            gui.set_theme(str(self.eval(node.theme, env)))
        except Exception:
            pass
        return None
    if tname == 'SetColorStatement':
        try:
            gui = self._get_gui(env)
            gui.set_color(node.widget, str(self.eval(node.color, env)))
        except Exception:
            pass
        return None
    if tname == 'SetFontStatement':
        return None   # font changes handled in widget re-config
    if tname == 'CreateLayoutStatement':
        gui = self._get_gui(env)
        title = self._interpolate(self.eval(node.title, env), env) \
                if node.title else ''
        gui.create_layout(node.layout_type, node.name, title)
        return None
    if tname == 'AddToLayoutStatement':
        gui = self._get_gui(env)
        gui.add_to_layout(node.widgets, node.layout)
        return None
    if tname == 'ShowToastStatement':
        msg = self._interpolate(self.eval(node.message, env), env)
        dur = int(self.eval(node.duration, env)) * 1000 \
              if node.duration else 3000
        try:
            gui = self._get_gui(env)
            gui.show_toast(msg, dur)
        except Exception:
            print(f"[Toast] {msg}")
        return None
    if tname == 'CreateChartStatement':
        gui = self._get_gui(env)
        title = self._interpolate(self.eval(node.title, env), env) \
                if node.title else ''
        gui.create_chart(node.chart_type, node.name, title)
        return None
    if tname == 'SetChartDataStatement':
        gui = self._get_gui(env)
        labels = self.eval(node.labels, env)
        values = self.eval(node.values, env) if node.values else None
        gui.set_chart_data(node.chart, labels, values)
        return None
    if tname == 'CreateTableStatement':
        gui = self._get_gui(env)
        cols = [str(self.eval(c, env)) for c in node.columns]
        gui.create_table(node.name, cols)
        return None
    if tname == 'AddRowStatement':
        gui = self._get_gui(env)
        vals = [self.eval(v, env) for v in node.values]
        gui.add_row_to_table(node.table, vals)
        return None
    if tname == 'CreateProgressStatement':
        gui = self._get_gui(env)
        gui.create_progress(node.name)
        return None
    if tname == 'SetProgressStatement':
        val = self.eval(node.value, env)
        try:
            gui = self._get_gui(env)
            gui.set_progress_value(node.name, float(val))
        except Exception:
            pass
        return None
    if tname == 'CreateToggleStatement':
        gui = self._get_gui(env)
        text = self._interpolate(self.eval(node.text, env), env) \
               if node.text else ''
        gui.create_toggle(node.name, text)
        return None
    if tname == 'CreateDropdownStatement':
        gui = self._get_gui(env)
        choices = [str(self.eval(c, env)) for c in node.choices]
        gui.create_dropdown(node.name, choices)
        return None
    if tname == 'CreateSliderStatement':
        gui = self._get_gui(env)
        mn = float(self.eval(node.min_val, env)) if node.min_val else 0
        mx = float(self.eval(node.max_val, env)) if node.max_val else 100
        gui.create_slider(node.name, mn, mx)
        return None
    if tname == 'WaitStatement':
        import time
        dur = float(self.eval(node.duration, env))
        time.sleep(dur)
        return None
    if tname == 'EveryStatement':
        # Register a repeating timer (runs after GUI starts)
        try:
            gui = self._get_gui(env)
            interval_ms = int(float(self.eval(node.interval, env)) * 1000)
            cb_name = node.callback
            ev = self

            def register_timer():
                if gui._root is None:
                    return
                def tick():
                    try:
                        fn = ev.global_env.get(cb_name)
                        ev._call_function(fn, [], ev.global_env)
                    except Exception as e:
                        print(f"Timer error: {e}")
                    gui._root.after(interval_ms, tick)
                gui._root.after(interval_ms, tick)

            gui._pending_timers = getattr(gui, '_pending_timers', [])
            gui._pending_timers.append(register_timer)
        except Exception:
            pass
        return None
    if tname == 'SqlConnectStatement':
        return self._exec_sql_connect(node, env)
    if tname == 'SqlExecuteStatement':
        return self._exec_sql_execute(node, env)
    if tname == 'CsvWriteStatement':
        return self._exec_csv_write(node, env)

    return _orig_exec(self, node, env)

Evaluator.exec = _new_exec


# ── Expression eval extensions ────────────────────────────────────────────────

_orig_eval = Evaluator.eval

def _new_eval(self, node, env):
    if node is None:
        return None
    tname = type(node).__name__

    if tname == 'HttpGetExpr':
        return self._eval_http_get(node, env)
    if tname == 'HttpPostExpr':
        return self._eval_http_post(node, env)
    if tname == 'SqlQueryExpr':
        return self._eval_sql_query(node, env)
    if tname == 'CsvReadExpr':
        return self._eval_csv_read(node, env)
    if tname == 'MaxOfExpr':
        v = self.eval(node.target, env)
        return max(v) if v else None
    if tname == 'MinOfExpr':
        v = self.eval(node.target, env)
        return min(v) if v else None
    if tname == 'SumOfExpr':
        v = self.eval(node.target, env)
        return sum(v) if v else 0
    if tname == 'SortedExpr':
        lst = list(self.eval(node.target, env))
        key = node.key
        rev = node.descending
        if key:
            return sorted(lst,
                           key=lambda x: x[key] if isinstance(x, dict) else x,
                           reverse=rev)
        return sorted(lst, reverse=rev)
    if tname == 'FilteredExpr':
        lst = self.eval(node.target, env)
        result = []
        for item in lst:
            sub = Environment(env)
            sub.define(node.variable, item)
            if self._truthy(self.eval(node.condition, sub)):
                result.append(item)
        return result
    if tname == 'JoinedListExpr':
        lst = self.eval(node.target, env)
        sep = str(self.eval(node.separator, env))
        return sep.join(str(x) for x in lst)

    return _orig_eval(self, node, env)

Evaluator.eval = _new_eval


# ── New executor methods ───────────────────────────────────────────────────────

def _exec_include(self, node, env):
    import os
    path = str(self.eval(node.path, env))
    # Resolve relative to current working directory
    if not os.path.isabs(path):
        path = os.path.join(os.getcwd(), path)
    if not os.path.exists(path):
        raise LyraRuntimeError(f'I cannot find the file "{path}".', node.line)
    with open(path, 'r', encoding='utf-8') as f:
        source = f.read()
    from .parser import parse
    ast = parse(source)
    self.exec_block(ast.statements, env)

Evaluator._exec_include = _exec_include


def _exec_sql_connect(self, node, env):
    import sqlite3
    path = str(self.eval(node.path, env))
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    env.define(node.alias, conn)

Evaluator._exec_sql_connect = _exec_sql_connect


def _exec_sql_execute(self, node, env):
    import sqlite3
    db   = env.get(node.db)
    sql  = str(self.eval(node.sql, env))
    params = self.eval(node.params, env) if node.params else []
    if isinstance(params, list):
        params = tuple(params)
    elif not isinstance(params, (tuple, list)):
        params = (params,)
    cur = db.execute(sql, params)
    db.commit()
    return cur.lastrowid

Evaluator._exec_sql_execute = _exec_sql_execute


def _exec_csv_write(self, node, env):
    import csv
    data = self.eval(node.data, env)
    path = str(self.eval(node.path, env))
    with open(path, 'w', newline='', encoding='utf-8') as f:
        if data and isinstance(data[0], dict):
            writer = csv.DictWriter(f, fieldnames=list(data[0].keys()))
            writer.writeheader()
            writer.writerows(data)
        elif data and isinstance(data[0], list):
            writer = csv.writer(f)
            writer.writerows(data)
        else:
            writer = csv.writer(f)
            writer.writerow(data)

Evaluator._exec_csv_write = _exec_csv_write


def _eval_http_get(self, node, env):
    import urllib.request, urllib.parse, json as _json
    url = str(self.eval(node.url, env))
    try:
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'LyraLang/2.0')
        with urllib.request.urlopen(req, timeout=10) as resp:
            body = resp.read().decode('utf-8')
        return body
    except Exception as e:
        raise LyraRuntimeError(f'HTTP GET failed for "{url}": {e}', node.line)

Evaluator._eval_http_get = _eval_http_get


def _eval_http_post(self, node, env):
    import urllib.request, urllib.parse, json as _json
    url  = str(self.eval(node.url, env))
    data = self.eval(node.data, env)
    try:
        if isinstance(data, dict):
            payload = _json.dumps(data).encode('utf-8')
            req = urllib.request.Request(url, data=payload,
                                          headers={'Content-Type': 'application/json',
                                                   'User-Agent': 'LyraLang/2.0'})
        else:
            payload = str(data).encode('utf-8')
            req = urllib.request.Request(url, data=payload)
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.read().decode('utf-8')
    except Exception as e:
        raise LyraRuntimeError(f'HTTP POST failed for "{url}": {e}', node.line)

Evaluator._eval_http_post = _eval_http_post


def _eval_sql_query(self, node, env):
    db  = env.get(node.db)
    sql = str(self.eval(node.sql, env))
    cur = db.execute(sql)
    rows = cur.fetchall()
    # Return list of dicts
    return [dict(row) for row in rows]

Evaluator._eval_sql_query = _eval_sql_query


def _eval_csv_read(self, node, env):
    import csv
    path = str(self.eval(node.path, env))
    rows = []
    with open(path, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            rows.append(dict(row))
    return rows

Evaluator._eval_csv_read = _eval_csv_read


# Patch exec_create_widget to handle all new widget types
_orig_create_widget = Evaluator.exec_create_widget

def _new_create_widget(self, node, env):
    gui  = self._get_gui(env)
    wt   = node.widget_type.lower().strip()
    name = node.name
    text = self._interpolate(self.eval(node.text, env), env) \
           if node.text else ''

    if 'label' in wt or 'heading' in wt or 'title' in wt:
        gui.create_label(name, text)
    elif 'button' in wt or 'btn' in wt:
        gui.create_button(name, text, node.callback, self)
    elif 'input' in wt or 'entry' in wt or 'field' in wt or 'textbox' in wt:
        placeholder = self._interpolate(self.eval(node.placeholder, env), env) \
                      if node.placeholder else text
        gui.create_text_input(name, placeholder)
    elif 'checkbox' in wt or 'check' in wt:
        gui.create_checkbox(name, text)
    elif 'toggle' in wt or 'switch' in wt:
        gui.create_toggle(name, text)
    elif 'dropdown' in wt or 'select' in wt or 'menu' in wt:
        gui.create_dropdown(name, [text])
    elif 'slider' in wt:
        gui.create_slider(name, 0, 100)
    elif 'progress' in wt:
        gui.create_progress(name)
    elif 'table' in wt:
        gui.create_table(name, [])
    else:
        gui.create_label(name, text)

Evaluator.exec_create_widget = _new_create_widget


# Patch exec_show_window to start pending timers
_orig_show_window = Evaluator.exec_show_window

def _new_exec_show_window(self, node, env):
    gui = self._get_gui(env)
    # After root is created and before mainloop, fire timers
    import tkinter as tk

    # Monkey-patch show_window to set up timers after root creation
    original_sw = gui.show_window
    ev = self

    def patched_show(evaluator=None):
        ev2 = evaluator or ev
        gui.show_window = original_sw

        import tkinter as tk

        # We need to intercept right after root is created
        # so store timers and call them via root.after(0, ...)
        original_sw.__func__  # check it's a bound method

        # Call original
        original_sw(ev2)

    try:
        patched_show(self)
    except Exception:
        gui.show_window = original_sw
        gui.show_window(self)

Evaluator.exec_show_window = _orig_show_window  # keep the clean version


# Patch _load_gui to pass evaluator
def _load_gui_v2(self, alias, env):
    try:
        from .gui import LyraGUI
        gui = LyraGUI(env)
        gui._evaluator = self
        env.define('__gui__', gui)
    except Exception as ex:
        print(f"Warning: GUI module could not load: {ex}")

Evaluator._load_gui = _load_gui_v2

# ── Lyra 2.0: Patch _load_module to use stdlib registry ─────────────────────

_orig_load_module = Evaluator._load_module

def _new_load_module(self, module: str, alias: str, language, env):
    """Extended module loader — tries stdlib registry before legacy map."""
    from lyra.stdlib import load_module as stdlib_load
    if stdlib_load(module.lower(), env, self):
        return  # Loaded from registry

    # If we have a web_server module, register evaluator ref
    import lyra.stdlib.web_server as _ws_mod
    _ws_mod._evaluator_ref = self

    # Fall through to original loader
    _orig_load_module(self, module, alias, language, env)

Evaluator._load_module = _new_load_module
