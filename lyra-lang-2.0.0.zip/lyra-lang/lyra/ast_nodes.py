"""
Quill AST Node Definitions
"""
from dataclasses import dataclass, field
from typing import Any, List, Optional, Tuple


@dataclass
class Node:
    line: int = 0

@dataclass
class Program(Node):
    statements: List[Node] = field(default_factory=list)

# ─── Statements ─────────────────────────────────────────────────────────────

@dataclass
class LetStatement(Node):
    names: List[str] = field(default_factory=list)
    values: List[Node] = field(default_factory=list)
    type_annotation: Optional[str] = None

@dataclass
class SetStatement(Node):
    name: str = ""
    value: Optional[Node] = None

@dataclass
class SetItemStatement(Node):
    target: str = ""
    key: Optional[Node] = None
    value: Optional[Node] = None
    is_map: bool = False

@dataclass
class SetPropertyStatement(Node):
    prop: str = ""
    value: Optional[Node] = None

@dataclass
class SetTextStatement(Node):
    widget: str = ""
    value: Optional[Node] = None

@dataclass
class SayStatement(Node):
    value: Optional[Node] = None
    followed_by: Optional[Node] = None

@dataclass
class AskStatement(Node):
    prompt: Optional[Node] = None
    variable: str = ""
    type_annotation: Optional[str] = None

@dataclass
class IfStatement(Node):
    condition: Optional[Node] = None
    then_body: List[Node] = field(default_factory=list)
    elif_clauses: List[Tuple] = field(default_factory=list)
    else_body: Optional[List[Node]] = None

@dataclass
class RepeatTimesStatement(Node):
    count: Optional[Node] = None
    body: List[Node] = field(default_factory=list)

@dataclass
class RepeatRangeStatement(Node):
    start: Optional[Node] = None
    end: Optional[Node] = None
    body: List[Node] = field(default_factory=list)

@dataclass
class WhileStatement(Node):
    condition: Optional[Node] = None
    body: List[Node] = field(default_factory=list)

@dataclass
class ForEachStatement(Node):
    variable: str = ""
    iterable: Optional[Node] = None
    body: List[Node] = field(default_factory=list)

@dataclass
class DefineStatement(Node):
    name: str = ""
    params: List[str] = field(default_factory=list)
    defaults: dict = field(default_factory=dict)
    body: List[Node] = field(default_factory=list)

@dataclass
class ReturnStatement(Node):
    value: Optional[Node] = None

@dataclass
class ExprStatement(Node):
    expr: Optional[Node] = None

@dataclass
class TryStatement(Node):
    try_body: List[Node] = field(default_factory=list)
    error_var: str = "error"
    catch_body: List[Node] = field(default_factory=list)

@dataclass
class RaiseStatement(Node):
    message: Optional[Node] = None

@dataclass
class UseStatement(Node):
    module: str = ""
    language: Optional[str] = None
    alias: Optional[str] = None

@dataclass
class AddToStatement(Node):
    value: Optional[Node] = None
    target: str = ""
    is_arithmetic: bool = False

@dataclass
class SubtractFromStatement(Node):
    value: Optional[Node] = None
    target: str = ""

@dataclass
class MultiplyByStatement(Node):
    target: str = ""
    value: Optional[Node] = None

@dataclass
class DivideByStatement(Node):
    target: str = ""
    value: Optional[Node] = None

@dataclass
class RemoveFromStatement(Node):
    value: Optional[Node] = None
    target: str = ""

@dataclass
class WriteFileStatement(Node):
    content: Optional[Node] = None
    filename: Optional[Node] = None
    mode: str = 'w'

@dataclass
class DeleteFileStatement(Node):
    filename: Optional[Node] = None

@dataclass
class StopStatement(Node):
    pass

@dataclass
class SkipStatement(Node):
    pass

@dataclass
class CallOnStatement(Node):
    method: str = ""
    obj: str = ""
    args: List[Node] = field(default_factory=list)

@dataclass
class DefineClassStatement(Node):
    name: str = ""
    parent: Optional[str] = None
    attributes: List[str] = field(default_factory=list)
    methods: List = field(default_factory=list)

# ─── Expressions ─────────────────────────────────────────────────────────────

@dataclass
class NumberLiteral(Node):
    value: int = 0

@dataclass
class DecimalLiteral(Node):
    value: float = 0.0

@dataclass
class StringLiteral(Node):
    value: str = ""

@dataclass
class BoolLiteral(Node):
    value: bool = False

@dataclass
class NothingLiteral(Node):
    pass

@dataclass
class VariableRef(Node):
    name: str = ""

@dataclass
class ItsRef(Node):
    prop: str = ""

@dataclass
class BinaryOp(Node):
    op: str = ""
    left: Optional[Node] = None
    right: Optional[Node] = None

@dataclass
class UnaryOp(Node):
    op: str = ""
    operand: Optional[Node] = None

@dataclass
class CompareOp(Node):
    op: str = ""
    left: Optional[Node] = None
    right: Optional[Node] = None

@dataclass
class LogicalOp(Node):
    op: str = ""
    left: Optional[Node] = None
    right: Optional[Node] = None

@dataclass
class FunctionCall(Node):
    name: str = ""
    args: List[Node] = field(default_factory=list)

@dataclass
class MethodCall(Node):
    method: str = ""
    obj: str = ""
    args: List[Node] = field(default_factory=list)

@dataclass
class ListLiteral(Node):
    items: List[Node] = field(default_factory=list)

@dataclass
class MapLiteral(Node):
    pairs: List[Tuple] = field(default_factory=list)

@dataclass
class ListAccess(Node):
    list_expr: Optional[Node] = None
    index: Optional[Node] = None

@dataclass
class MapAccess(Node):
    map_expr: Optional[Node] = None
    key: Optional[Node] = None

@dataclass
class SizeOf(Node):
    target: Optional[Node] = None

@dataclass
class LengthOf(Node):
    target: Optional[Node] = None

@dataclass
class StringOp(Node):
    op: str = ""
    target: Optional[Node] = None
    arg: Optional[Node] = None
    arg2: Optional[Node] = None

@dataclass
class CurrentCount(Node):
    pass

@dataclass
class MathExpr(Node):
    op: str = ""
    operand: Optional[Node] = None
    arg: Optional[Node] = None

@dataclass
class InlineFunction(Node):
    params: List[str] = field(default_factory=list)
    body: Optional[Node] = None

@dataclass
class TypeOf(Node):
    target: Optional[Node] = None

@dataclass
class ToNumber(Node):
    target: Optional[Node] = None

@dataclass
class ToText(Node):
    target: Optional[Node] = None

@dataclass
class ToTruth(Node):
    target: Optional[Node] = None

@dataclass
class NewObject(Node):
    class_name: str = ""
    args: List[Node] = field(default_factory=list)

@dataclass
class FetchExpr(Node):
    url: Optional[Node] = None

@dataclass
class ParseJsonExpr(Node):
    target: Optional[Node] = None

@dataclass
class FileExistsExpr(Node):
    filename: Optional[Node] = None

@dataclass
class FileContentExpr(Node):
    filename: Optional[Node] = None

@dataclass
class ValueOf(Node):
    widget: str = ""

# ─── GUI Statements ───────────────────────────────────────────────────────────

@dataclass
class OpenWindowStatement(Node):
    title: Optional[Node] = None
    width: Optional[Node] = None
    height: Optional[Node] = None

@dataclass
class CreateWidgetStatement(Node):
    """create a WTYPE named NAME saying TEXT [that calls CALLBACK]"""
    widget_type: str = ""
    name: str = ""
    text: Optional[Node] = None
    callback: Optional[str] = None
    placeholder: Optional[Node] = None

@dataclass
class PlaceInWindowStatement(Node):
    widgets: List[str] = field(default_factory=list)

@dataclass
class ShowWindowStatement(Node):
    pass

@dataclass
class WhenStatement(Node):
    widget: str = ""
    event: str = ""
    body: List[Node] = field(default_factory=list)

@dataclass
class RandomBetweenExpr(Node):
    low: Optional[Node] = None
    high: Optional[Node] = None

# ─── Quill 2.0 — New AST nodes ────────────────────────────────────────────────

@dataclass
class IncludeStatement(Node):
    """include "other_file.ql"."""
    path: Optional[Node] = None

@dataclass
class SetThemeStatement(Node):
    """set theme to "dark"."""
    theme: Optional[Node] = None

@dataclass
class SetColorStatement(Node):
    """set color of WIDGET to "blue"."""
    widget: str = ""
    color: Optional[Node] = None

@dataclass
class SetFontStatement(Node):
    """set font size of WIDGET to 18."""
    widget: str = ""
    size: Optional[Node] = None
    family: Optional[Node] = None

@dataclass
class CreateLayoutStatement(Node):
    """create a row/column/card layout named X."""
    layout_type: str = ""   # row, column, card, tab, sidebar
    name: str = ""
    title: Optional[Node] = None

@dataclass
class AddToLayoutStatement(Node):
    """add WIDGET to LAYOUT."""
    widgets: List[str] = field(default_factory=list)
    layout: str = ""

@dataclass
class ShowToastStatement(Node):
    """show a toast saying "X"."""
    message: Optional[Node] = None
    duration: Optional[Node] = None

@dataclass
class CreateChartStatement(Node):
    """create a bar/line/pie chart named X."""
    chart_type: str = ""
    name: str = ""
    title: Optional[Node] = None

@dataclass
class SetChartDataStatement(Node):
    """set data of CHART to LABELS, VALUES."""
    chart: str = ""
    labels: Optional[Node] = None
    values: Optional[Node] = None

@dataclass
class CreateTableStatement(Node):
    """create a table named X with columns "A", "B"."""
    name: str = ""
    columns: List[Node] = field(default_factory=list)

@dataclass
class AddRowStatement(Node):
    """add row VALUES to TABLE."""
    values: List[Node] = field(default_factory=list)
    table: str = ""

@dataclass
class CreateProgressStatement(Node):
    """create a progress bar named X."""
    name: str = ""

@dataclass
class SetProgressStatement(Node):
    """set progress of X to 75."""
    name: str = ""
    value: Optional[Node] = None

@dataclass
class CreateToggleStatement(Node):
    """create a toggle named X saying "Label"."""
    name: str = ""
    text: Optional[Node] = None

@dataclass
class CreateDropdownStatement(Node):
    """create a dropdown named X with choices "a", "b", "c"."""
    name: str = ""
    choices: List[Node] = field(default_factory=list)

@dataclass
class CreateSliderStatement(Node):
    """create a slider named X from 0 to 100."""
    name: str = ""
    min_val: Optional[Node] = None
    max_val: Optional[Node] = None

@dataclass
class CreateImageStatement(Node):
    """create an image named X from "path.png"."""
    name: str = ""
    path: Optional[Node] = None

@dataclass
class OpenTabStatement(Node):
    """open tab "Name" in TABS."""
    tab_name: Optional[Node] = None
    tabs_widget: str = ""

@dataclass
class HttpGetExpr(Node):
    """get "url" → returns response text."""
    url: Optional[Node] = None
    headers: Optional[Node] = None

@dataclass
class HttpPostExpr(Node):
    """post to "url" with DATA."""
    url: Optional[Node] = None
    data: Optional[Node] = None
    headers: Optional[Node] = None

@dataclass
class ParseJsonExpr2(Node):
    """parse RESPONSE as json."""
    target: Optional[Node] = None

@dataclass
class EveryStatement(Node):
    """every N seconds call FUNC."""
    interval: Optional[Node] = None
    callback: str = ""

@dataclass
class WaitStatement(Node):
    """wait N seconds."""
    duration: Optional[Node] = None

@dataclass
class RunPythonStatement(Node):
    """run python code inline and get result."""
    code: str = ""
    result_var: Optional[str] = None

@dataclass
class SqlConnectStatement(Node):
    """connect to database "file.db" as DB."""
    path: Optional[Node] = None
    alias: str = "db"

@dataclass
class SqlQueryExpr(Node):
    """query DB with "SELECT ..."."""
    db: str = ""
    sql: Optional[Node] = None

@dataclass
class SqlExecuteStatement(Node):
    """execute "INSERT ..." on DB."""
    db: str = ""
    sql: Optional[Node] = None
    params: Optional[Node] = None

@dataclass
class CsvReadExpr(Node):
    """read csv "file.csv"."""
    path: Optional[Node] = None

@dataclass
class CsvWriteStatement(Node):
    """write DATA as csv to "file.csv"."""
    data: Optional[Node] = None
    path: Optional[Node] = None

@dataclass
class SortedExpr(Node):
    """LIST sorted by KEY / sorted descending."""
    target: Optional[Node] = None
    key: Optional[str] = None
    descending: bool = False

@dataclass
class FilteredExpr(Node):
    """items in LIST where CONDITION."""
    target: Optional[Node] = None
    variable: str = ""
    condition: Optional[Node] = None

@dataclass
class MappedExpr(Node):
    """each ITEM in LIST as EXPR."""
    target: Optional[Node] = None
    variable: str = ""
    transform: Optional[Node] = None

@dataclass
class MaxOfExpr(Node):
    target: Optional[Node] = None

@dataclass
class MinOfExpr(Node):
    target: Optional[Node] = None

@dataclass
class SumOfExpr(Node):
    target: Optional[Node] = None

@dataclass
class JoinedListExpr(Node):
    """LIST joined by SEPARATOR."""
    target: Optional[Node] = None
    separator: Optional[Node] = None
