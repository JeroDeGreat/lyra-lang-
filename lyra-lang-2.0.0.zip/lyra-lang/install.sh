#!/usr/bin/env bash
# ════════════════════════════════════════════════════════════════
#  Quill Language Installer  —  macOS / Linux
#  "Write code the way you think."
# ════════════════════════════════════════════════════════════════
set -e

QUILL_VERSION="1.0.0"
INSTALL_DIR="$HOME/.quill"
BIN_DIR="$INSTALL_DIR/bin"
QUILL_REPO="https://github.com/quill-lang/quill"
QUILL_PYPI="quill-lang"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

header() {
    echo ""
    echo -e "${CYAN}╔═══════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}║   ${BOLD}Quill ${QUILL_VERSION}${NC}${CYAN}  —  Write code the way you think.   ║${NC}"
    echo -e "${CYAN}╚═══════════════════════════════════════════════════╝${NC}"
    echo ""
}

ok()   { echo -e "  ${GREEN}✓${NC}  $1"; }
info() { echo -e "  ${BLUE}→${NC}  $1"; }
warn() { echo -e "  ${YELLOW}⚠${NC}  $1"; }
fail() { echo -e "  ${RED}✗${NC}  $1"; exit 1; }

header

# ── Detect OS ─────────────────────────────────────────────────────
OS="$(uname -s)"
case "$OS" in
    Linux*)  PLATFORM="linux";;
    Darwin*) PLATFORM="macos";;
    *)       fail "Unsupported operating system: $OS";;
esac
info "Detected platform: $PLATFORM"

# ── Check Python 3.10+ ────────────────────────────────────────────
info "Checking for Python 3.10 or newer..."
PYTHON=""
for cmd in python3.12 python3.11 python3.10 python3 python; do
    if command -v "$cmd" &>/dev/null; then
        version=$("$cmd" -c 'import sys; print(sys.version_info[:2])' 2>/dev/null)
        major=$("$cmd" -c 'import sys; print(sys.version_info[0])' 2>/dev/null)
        minor=$("$cmd" -c 'import sys; print(sys.version_info[1])' 2>/dev/null)
        if [ "$major" -ge 3 ] && [ "$minor" -ge 10 ] 2>/dev/null; then
            PYTHON="$cmd"
            ok "Found Python $major.$minor at $(command -v $cmd)"
            break
        fi
    fi
done

if [ -z "$PYTHON" ]; then
    fail "Python 3.10 or newer is required. Download from https://python.org"
fi

# ── Create install directory ──────────────────────────────────────
info "Creating install directory at $INSTALL_DIR..."
mkdir -p "$BIN_DIR"
ok "Directory ready"

# ── Install via pip ───────────────────────────────────────────────
info "Installing Quill via pip..."
if "$PYTHON" -m pip install --quiet --upgrade "$QUILL_PYPI" --target "$INSTALL_DIR/lib" 2>/dev/null; then
    ok "Installed from PyPI"
else
    # Fallback: install from local directory if we're running from the repo
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    if [ -f "$SCRIPT_DIR/setup.py" ] || [ -f "$SCRIPT_DIR/pyproject.toml" ]; then
        info "Installing from local source..."
        "$PYTHON" -m pip install --quiet --upgrade "$SCRIPT_DIR" --target "$INSTALL_DIR/lib"
        ok "Installed from local source"
    else
        fail "Could not install Quill. Please try: pip install quill-lang"
    fi
fi

# ── Create launcher script ────────────────────────────────────────
info "Creating quill launcher..."
cat > "$BIN_DIR/quill" << LAUNCHER
#!/usr/bin/env bash
export PYTHONPATH="\$HOME/.quill/lib:\$PYTHONPATH"
exec "$PYTHON" -m quill "\$@"
LAUNCHER
chmod +x "$BIN_DIR/quill"
ok "Launcher created at $BIN_DIR/quill"

# ── Register .ql file association (Linux) ─────────────────────────
if [ "$PLATFORM" = "linux" ]; then
    info "Registering .ql file type..."
    
    # Create MIME type
    MIME_DIR="$HOME/.local/share/mime/packages"
    mkdir -p "$MIME_DIR"
    cat > "$MIME_DIR/text-x-quill.xml" << MIMEEOF
<?xml version="1.0" encoding="UTF-8"?>
<mime-info xmlns="http://www.freedesktop.org/standards/shared-mime-info">
  <mime-type type="text/x-quill">
    <comment>Quill source code</comment>
    <glob pattern="*.ql"/>
    <icon name="text-x-quill"/>
  </mime-type>
</mime-info>
MIMEEOF
    
    # Install desktop entry for opening .ql files
    APPS_DIR="$HOME/.local/share/applications"
    mkdir -p "$APPS_DIR"
    cat > "$APPS_DIR/quill-runner.desktop" << DESKEOF
[Desktop Entry]
Type=Application
Name=Quill Runner
Comment=Run Quill (.ql) programs
Exec=$BIN_DIR/quill run %f
Icon=$INSTALL_DIR/quill-icon.png
Terminal=true
Categories=Development;
MimeType=text/x-quill;
DESKEOF
    
    # Update MIME database if possible
    if command -v update-mime-database &>/dev/null; then
        update-mime-database "$HOME/.local/share/mime" 2>/dev/null || true
    fi
    if command -v update-desktop-database &>/dev/null; then
        update-desktop-database "$APPS_DIR" 2>/dev/null || true
    fi
    ok "File type .ql registered"
fi

# Register .ql on macOS
if [ "$PLATFORM" = "macos" ]; then
    info "Registering .ql file type on macOS..."
    # macOS uses UTI — create a LaunchServices plist
    PLIST_DIR="$HOME/Library/LaunchServices"
    mkdir -p "$PLIST_DIR"
    # Just note: full UTI registration requires an app bundle; we note it's text
    ok "macOS: .ql files will open as plain text (install the VS Code extension for full support)"
fi

# ── Add to PATH ───────────────────────────────────────────────────
info "Adding $BIN_DIR to your PATH..."

PATH_LINE="export PATH=\"\$HOME/.quill/bin:\$PATH\""
PATH_ADDED=false

add_to_shell() {
    local rc_file="$1"
    if [ -f "$rc_file" ]; then
        if ! grep -q ".quill/bin" "$rc_file" 2>/dev/null; then
            echo "" >> "$rc_file"
            echo "# Quill Language" >> "$rc_file"
            echo "$PATH_LINE" >> "$rc_file"
            ok "Added to $rc_file"
            PATH_ADDED=true
        else
            ok "Already in $rc_file"
            PATH_ADDED=true
        fi
    fi
}

add_to_shell "$HOME/.bashrc"
add_to_shell "$HOME/.bash_profile"
add_to_shell "$HOME/.zshrc"
add_to_shell "$HOME/.profile"

if [ "$PATH_ADDED" = false ]; then
    warn "Could not find a shell config file. Add this line manually:"
    echo "  $PATH_LINE"
fi

# ── Install VS Code extension (if VS Code is installed) ───────────
if command -v code &>/dev/null; then
    VSIX_PATH="$INSTALL_DIR/quill-lang.vsix"
    if [ -f "$VSIX_PATH" ]; then
        info "Installing VS Code extension..."
        code --install-extension "$VSIX_PATH" --force 2>/dev/null && ok "VS Code extension installed" || warn "VS Code extension install failed (manual install: code --install-extension $VSIX_PATH)"
    else
        info "Install the VS Code extension from: https://marketplace.visualstudio.com/items?itemName=quill-lang.quill"
    fi
fi

# ── Verify installation ───────────────────────────────────────────
export PATH="$BIN_DIR:$PATH"
info "Verifying installation..."
if "$BIN_DIR/quill" version &>/dev/null; then
    ok "Quill installed successfully!"
    VERSION=$("$BIN_DIR/quill" version 2>/dev/null | head -1)
    echo ""
    echo -e "${BOLD}$VERSION${NC}"
else
    warn "Install succeeded but 'quill' command not found in PATH yet."
fi

# ── Done ──────────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}${BOLD}🪶 Quill is ready!${NC}"
echo ""
echo "  Quick start:"
echo -e "  ${CYAN}source ~/.bashrc${NC}          # Apply PATH changes"
echo -e "  ${CYAN}quill version${NC}             # Verify install"
echo -e "  ${CYAN}quill repl${NC}                # Start interactive REPL"
echo -e "  ${CYAN}quill new myproject${NC}       # Create a new project"
echo -e "  ${CYAN}quill run myfile.ql${NC}       # Run a .ql file"
echo ""
echo "  VS Code Extension:"
echo "  Search 'Quill Language Support' in the Extensions panel"
echo "  or visit: https://marketplace.visualstudio.com/items?itemName=quill-lang.quill"
echo ""
